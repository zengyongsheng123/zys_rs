// --------------------------------------你要导入的模块包--------------------------------------------------------
const CryptoJs = require("crypto-js");
window=globalThis
function watch(obj,name){
    console_log= console.log
    return new Proxy(obj,{
        get(target, p, receiver) {
            if(p===Symbol.toPrimitive||p===Symbol.toStringTag||p==="Math"||p==="isNaN"||p==="encodeURI"||p==="Uint8Array"){

                return Reflect.get(target, p, receiver);
            }else {

                let  vel = Reflect.get(...arguments)
                if((typeof vel) ==='object'){
                    console_log('取值:',name,'.',p,'=>',typeof vel)
                    return Reflect.get(target, p, receiver);
                }
                if(p==='da_toString'){
                    return Reflect.get(target, p, receiver);
                }
                console_log('取值:',name,'.',p,'=>',vel)
                return Reflect.get(target, p, receiver);
            }
        },
        set(target, p, newValue, receiver) {
            let val = Reflect.get(...arguments)
            console_log(`设置值${name}.${p},${val}=>${newValue}`)
            return Reflect.set(target, p, newValue, receiver);
        }   ,
        has(target, p) {
            console_log(`in检测:${"'"+p+"'"} in ${name}=>>${p in target}`)
            return Reflect.has(target, p);
        },
        deleteProperty(target, p) {
            console_log(`删除了${name}中的${p}`)
            return Reflect.deleteProperty(target, p);

        },
        ownKeys(target) {
            console.log(`正在获取${name}对象的自有属性键`);
            return Reflect.ownKeys(target);
        },
        // getOwnPropertyDescriptor(target, p) {
        //     console.log(`获取了${name}中的${p}属性的描述符`);
        //     return Reflect.getOwnPropertyDescriptor(target, p);
        //
        // },
        // defineProperty(target, property, descriptor) {
        //     return Reflect.defineProperty(target, property, descriptor);
        // },
        getPrototypeOf(target) {
            console.log(`利用getPrototypeOf获取${name}对象中的原型链属性`);
            return  Reflect.getPrototypeOf(target);
        },
        // preventExtensions(target) {
        //     return Reflect.preventExtensions(target);
        // },
        // isExtensible(target) {
        //     return Reflect.isExtensible(target);
        // },
        // setPrototypeOf(target, prototype) {
        //     console.log(`利用setPrototypeOf设置了${name}中的设置了原型链对象属性`);
        //     return Reflect.setPrototypeOf(target, prototype);;
        // },
        apply(target, thisArg, args) {
            console.log(`${name}方法接收了`,args);
            return Reflect.apply(target, thisArg, args);
        },
        construct(target, args, newTarget) {
            console.log(`${name}方法构造参数接收了`,args);
            return  Reflect.construct(target, args, newTarget);
        }
    })
}
watch=function (a,b){
    return a
}
function makeFun(name) {
    //方法保护
    func = function () {
        console.log(`${name}-->`,arguments)
    };
    Object.defineProperty(func, 'name', { value: name });
    ps={}
    ps=watch(ps,`${name}.prototype`)
    func.prototype=ps
    func= watch(func,`${name}`)
    return func
}
setTimeout=function (){}
setInterval=function (){}
crypto=watch({},'crypto')
Element=makeFun('Element')
Element.prototype.da_toString=function (){
    return 'Element'
}
screen={
    da_toString:function (){
        return 'screen'
    },
    availHeight:816,
    availLeft:0,
    availTop:0,
    availWidth:1536,
    colorDepth:24,
    height:864,
    isExtended:false,
    onchange:null,
    orientation:{
        angle:0,
        onchange:null,
        type:"landscape-primary",
    },
    pixelDepth:24,
    width:1536,
}
document={
    da_toString:function (){
        return 'document'
    },

    createElement:function (a){
        // console.log("document-->createElement",a)
        if(a==='script'){
            script={
                parentNode:null,
            }
            script=watch(script,'script')
            return script
        }
    },
    createEvent:function (a){
        // console.log('document-->createEvent',a)
    },
    documentElement:watch({},'document.documentElement'),
    querySelector:makeFun('querySelector'),
    getElementsByTagName:function (a){
        // console.log('document-->getElementsByTagName',a)
        if(a==='head'){
            head={
                0:watch({
                    appendChild:function (a){
                        return a
                    },
                },'head[0]')
            }
            head=watch(head,'head')
            return head
        }
    },


}
navigator={
    lp:globalThis,
    appCodeName:"Mozilla",
    appName:"Netscape",
    appVersion:"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0",
    deprecatedRunAdAuctionEnforcesKAnonymity:false,
    deviceMemory:8,
    vendor:"Google Inc.",
    vendorSub:"",
    language:"zh-CN",
    languages:['zh-CN'],
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0",
    vendor:"Google Inc.",
    vendorSub:"",
    webdriver:false,
    da_toString:function (){
        return 'navigator'
    },
}
location={
    "ancestorOrigins": {},
    "href": "https://ntp.msn.cn/edge/ntp?locale=zh-CN&title=%E6%96%B0%E5%BB%BA%E6%A0%87%E7%AD%BE%E9%A1%B5&dsp=1&sp=%E5%BF%85%E5%BA%94&PC=CNNDDB&adppc=EDGEESS",
    "origin": "https://ntp.msn.cn",
    "protocol": "https:",
    "host": "ntp.msn.cn",
    "hostname": "ntp.msn.cn",
    "port": "",
    "pathname": "/edge/ntp",
    "search": "?locale=zh-CN&title=%E6%96%B0%E5%BB%BA%E6%A0%87%E7%AD%BE%E9%A1%B5&dsp=1&sp=%E5%BF%85%E5%BA%94&PC=CNNDDB&adppc=EDGEESS",
    "hash": ""
}
localStorage={
    getItem:function (a){
        // console.log("localStorage-->getItem",a)

    },

}
window=watch(window,'window')
document=watch(document,'document')
navigator=watch(navigator,'navigator')
location=watch(location,'location')
localStorage=watch(localStorage,'localStorage')
screen=watch(screen,'screen')
require("./h5st")
const timers = require("timers");
window.PSign = new ParamsSign({
    //融合接口加签
    appId: "b5216",
    //online
    debug: false,
    preRequest: false,
    onSign: function(res) {},
    // 算法请求监控回调事件 code: 200 - 请求成功，表示动态算法接口请求成功，获取到动态token 。 其他为失败
    onRequestTokenRemotely: function(res) {},
    onRequestToken: function(code, message) {}
});
const obj_ss = new window.ParamsSign()
timer = 1762263851855
p_s = 1762265586390    //Date().now()
pr = [
    "appid:www-jd-com",
    "body:44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a",
    "client:pc",
    "clientVersion:1.0.0",
    "functionId:jsfbox_getAdvertInfo",
    "t:1762263797215"
].join("&")
relk = "appid,body,client,clientVersion,functionId,t"
环境 = '{\n  "sua": "Windows NT 10.0; Win64; x64",\n  "pp": {},\n  "extend": {\n    "wd": 0,\n    "l": 0,\n    "ls": 5,\n    "wk": 0,\n    "bu1": "0.1.4",\n    "bu3": 36,\n    "bu4": 0,\n    "bu5": 0,\n    "bu6": 21,\n    "bu7": 0,\n    "bu8": 0,\n    "random": "A0LBcI23dT",\n    "bu12": -8,\n    "bu10": 14,\n    "bu11": 2,\n    "bu13": "Fh"\n  },\n  "pf": "Win32",\n  "random": "LyNfBb2Mg",\n  "v": "h5_file_v5.2.3",\n  "bu4": "0",\n  "canvas": "34310898711cbc67e174afd9403101a4",\n  "webglFp": "4a3d5a4e1ed70f80da6f60583689d1fa",\n  "ccn": 16,\n  "fp": "zzzmzt3zitqp3669"\n}'
a_p='__collect envCollect={\n  "sua": "Windows NT 10.0; Win64; x64",\n  "pp": {},\n  "extend": {\n    "wd": 0,\n    "l": 0,\n    "ls": 5,\n    "wk": 0,\n    "bu1": "0.1.4",\n    "bu3": 36,\n    "bu4": 0,\n    "bu5": 0,\n    "bu6": 21,\n    "bu7": 0,\n    "bu8": 0,\n    "random": "A0LBcI23dT",\n    "bu12": -8,\n    "bu10": 14,\n    "bu11": 2,\n    "bu13": "Fh"\n  },\n  "pf": "Win32",\n  "random": "LyNfBb2Mg",\n  "v": "h5_file_v5.2.3",\n  "bu4": "0",\n  "canvas": "34310898711cbc67e174afd9403101a4",\n  "webglFp": "4a3d5a4e1ed70f80da6f60583689d1fa",\n  "ccn": 16,\n  "fp": "zzzmzt3zitqp3669"\n}'
aaa = [
    "0",
    "5",
    "4",
    "3",
    "1",
    "2"
]
tk = "tk03wac271cb518nAXeUJ4d30CZxw99hVLxnSpMigAQbERuYqSLS0hrNKnVSxIHzv0L6DqzxHgJyUaXgc9K_-ZlWpFha" //
data = "zzzmzt3zitqp3669"//需要跟
vb = "53b5216cGQIzGuvWd4x"  //需要跟
se  = "yyyyMMddhhmmssSSS"

laa  = 'appid:appid&functionid:functionId'

lkvvvv="__genSignDefault, paramsStr:appid:appid&functionid:functionId, signedStr:"

base_arr = window._$pp.parse(环境)
base_64 = window._$OB.exports.encode(base_arr)
data_tim = window._$O6(p_s,se) // '20251104221310390'
 // console.log( new window._$ppa.init().)
md5 = new window._$pX.init(undefined).finalize(tk+data+data_tim+vb).toString()  //e12c124d411d70d39777b876f44115d3fd7c79f5064ba92757da8405d1f06b2f
me = md5+pr+md5  //e12c124d411d70d39777b876f44115d3fd7c79f5064ba92757da8405d1f06b2fappid:www-jd-com&body:44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a&client:pc&clientVersion:1.0.0&functionId:jsfbox_getAdvertInfo&t:1762263797215e12c124d411d70d39777b876f44115d3fd7c79f5064ba92757da8405d1f06b2f
 md5_2 = new window._$pX.init(undefined).finalize(me).toString()  //e3577e3b02b377655e56859ae70b1b8bc63e54b0a46116c7d0eed4dd3c91b422
cvc = '__genSign, paramsStr:' +pr+ ', signedStr:'+md5_2  //__genSign, paramsStr:appid:www-jd-com&body:44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a&client:pc&clientVersion:1.0.0&functionId:jsfbox_getAdvertInfo&t:1762263797215, signedStr:

fg = md5+laa+md5
mpp = new window._$pX.init(undefined).finalize(fg).toString() // 40643fb78ee9253d47028972fcf8d6bccf5de01498a441a2480ab38f53394ec1
lkvvvv +mpp   //"__genSignDefault, paramsStr:appid:appid&functionid:functionId, signedStr:40643fb78ee9253d47028972fcf8d6bccf5de01498a441a2480ab38f53394ec1"

base_key =  window._$OB.exports.encode(window._$pp.parse(relk))//gRaW989Gy8bE_oLE7w-Gy8

 h5st = data_tim+";"+data+";"+"b5216"+";"+tk+";"+md5_2+";"+"5.2"+";"+p_s+";"+base_64+";"+mpp+";"+base_key
console.log(h5st)