require('crypto-js')
const crypto = require("crypto-js");

function _0x38121c(_0x3d36e3,  miid) {
    return miid + "|" + "f6d4071c1aa5133ba2ca35801749d792869a8a3127548916c96ec9ec687f8999";
    }

var _0x3f32cd = _0x38121c("07020341-5123-4ae5-afdd-29fd625bfadd");
var _0x2b9afb = {
    hitId: "07020341-5123-4ae5-afdd-29fd625bfadd",
    deviceId: "6y8G0mMJTn3XfqTJdTb4TVjYESrbuWMjmqAIrZZe7RLOmsYGjZKwpcGmy0k8c4uIOihECvYiokFgC",
    weight: 0.2,
    print: _0x3f32cd
};
console.log(_0x2b9afb);
var _0x342a24 = null;
// window[_0x2b9afb.deviceId] = function (rc) {  // 这里后面要写活
window[_0x2b9afb.deviceId] = function () {  // 这里后面要写活
    return _0x342a24 = allocateUTF8("daVF80vaJgBy0g8SjhegiWzsf4rikiTSn/XIMBOfPf2NfyOfm/frY92HFQGVLHBu");
};
var _0x32f34d = allocateUTF8(JSON.stringify(_0x2b9afb));
var _0x528dd9 = _0x26183d._rotate(_0x32f34d);//  这里后面要写活而且是调用wasm里面的方法
var _0xbe1981 = _0x26183d.UTF8ToString(_0x528dd9);
_0x3e9fd1 = JSON.parse(_0xbe1981);
