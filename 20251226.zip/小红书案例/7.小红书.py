import json
import requests
import subprocess
from functools import partial

subprocess.Popen = partial(subprocess.Popen, encoding='utf-8')
import execjs

data = {
    "cursor_score": "",
    "num": 31,
    "refresh_type": 1,
    "note_index": 28,
    "unread_begin_note_id": "",
    "unread_end_note_id": "",
    "unread_note_count": 0,
    "category": "homefeed.food_v3",
    "search_key": "",
    "need_num": 6,
    "image_formats": [
        "jpg",
        "webp",
        "avif"
    ],
    "need_filter_image": False
}
encrypt_url = '/api/sns/web/v1/homefeed'

x_s = execjs.compile(open('6.main.js', 'r', encoding='utf-8').read()).call('seccore_signv2', encrypt_url, data)
print(x_s)
headers = {
    "accept": "application/json, text/plain, */*",
    "accept-language": "zh-CN,zh;q=0.9",
    "cache-control": "no-cache",
    "content-type": "application/json;charset=UTF-8",
    "origin": "https://www.xiaohongshu.com",
    "pragma": "no-cache",
    "priority": "u=1, i",
    "referer": "https://www.xiaohongshu.com/",
    "sec-ch-ua": "\"Google Chrome\";v=\"143\", \"Chromium\";v=\"143\", \"Not A(Brand\";v=\"24\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36",
    "x-b3-traceid": "4fa37328473a4d73",
    "x-s": x_s,
    "x-s-common": "2UQAPsHC+aIjqArjwjHjNsQhPsHCH0rjNsQhPaHCH0c1Pjh9HjIj2eHjwjQgynEDJ74AHjIj2ePjwjQhyoPTqBPT49pjHjIj2ecjwjHMN0Z1+UHVHdWMH0ijP/SjP0qUPBG7+/bdy7ZEJ7Sl4ob0+nMD2fhh49MSP/Z74dDA47mxPgZMPeZIPeql+0HhPjHVHdW9H0ijHjIj2eqjwjHjNsQhwsHCHDDAwoQH8B4AyfRI8FS98g+Dpd4daLP3JFSb/BMsn0pSPM87nrldzSzQ2bPAGdb7zgQB8nph8emSy9E0cgk+zSS1qgzianYt8p+s/LzN4gzaa/+NqMS6qS4HLozoqfQnPbZEp98QyaRSp9P98pSl4oSzcgmca/P78nTTL08z/sVManD9q9z18np/8db8aob7JeQl4epsPrzsagW3Lr4ryaRApdz3agYDq7YM47HFqgzkanYMGLSbP9LA/bGIa/+nprSe+9LI4gzVPDbrJg+P4fprLFTALMm7+LSb4d+kpdzt/7b7wrQM498cqBzSpr8g/FSh+bzQygL9nSm7qSmM4epQ4flY/BQdqA+l4oYQ2BpAPp87arS34nMQyFSE8nkdqMD6pMzd8/4SL7bF8aRr+7+rG7mkqBpD8pSUzozQcA8Szb87PDSb/d+/qgzVJfl/4LExpdzQ4fRSy7bFP9+y+7+nJAzdaLp/2LSizgbHwgbMagYiJdbCwB4QyFSfJ7b7yFSenS4o+A+A8BlO8p8c4A+Q4DbSPB8d8ncIyFkQy/pAPFSUz0QM4rbQyLTAynz98nTy/fpLLocFJDbO8p4c4FpQ4S+IGLbS8nzc47pdwLTAzop7cDDA+oQQ2rLM/op749bl4UTU8nTinDbw8/b+/fLILoqEaL+wqM8PJ9p/GDSBanT6qM+U+7+nJD8kanTdqM8n4rMQygpDqgb7t7zl4b4QPAmSPMm7aLSiJ9LA4gclanSOq9kM4e+74gz1qMm7nrSeG9lQPFSUP04VyAQQ+nLl4gzeaLp/NFSbadPILoz1qbSQcLuIafp88DclaLpULrRc4rT6qgqAa/+O8gYl4b4z/epSyn+mqA+Iyo4QyBRAPASOqA+M4o+0Lo4YaL+tqM4c4ApQyn4Sy9pl/rSea9px8sRA8SmF+LSh+7+h4g4r+BMrJDSkG0zQ2rESPUuIqMzY4d+DanpSyMm7cDSiL7YQcFGMNMm7cFSkzr4Q2epSPem3arlr8BL94g4+agYPy7bn4URTqDbSPnH7qAml49pS4gzya/+0cFSezrYspdqFt7pFaFDA+nLI2drRHjIj2eDjwjFl+0rUwePFw/GANsQhP/Zjw0HMNsQhP/rjwjQ1J7QTGnIjKc==",
    "x-t": "1765893790385",
    "x-xray-traceid": "cd93bc6d37a2d7a6e6d2256cc8c26b0c",
    "xy-direction": "59"
}
cookies = {
    # "a1": "19b2720f751gkp9oyqtqc5mdzn8wme107vy3wpj1p50000716282",
    # "webId": "dad4aa83cbc5735d4fb86a55a6fdd942",
    "gid": "yjDJWJy8iDWWyjDJWJ8iWhUV2ykTUjlvA9ASvyU26fuIYq28E6dy8E888WyKJYJ8K42yKSdK",
    # "abRequestId": "dad4aa83cbc5735d4fb86a55a6fdd942",
    # "webBuild": "5.0.7",
    # "xsecappid": "xhs-pc-web",
    "web_session": "030037ae7204e1ce52bed916392e4a38d6a4bc",
    # "loadts": "1765893668759",
    # "acw_tc": "0a5086d917658936656937388e1a7410ecda4f301787fb54dc256b4f6f18f7",
    # "websectiga": "f47eda31ec99545da40c2f731f0630efd2b0959e1dd10d5fedac3dce0bd1e04d",
    # "sec_poison_id": "dbe5c31d-439a-45eb-8234-6e8ee0939aba",
    # "unread": "{%22ub%22:%22693be592000000001e0235de%22%2C%22ue%22:%22693cd80b000000001d03e2d6%22%2C%22uc%22:29}"
}
url = "https://edith.xiaohongshu.com/api/sns/web/v1/homefeed"

data = json.dumps(data, separators=(',', ':'))
response = requests.post(url, headers=headers, cookies=cookies, data=data)

print(response.text)
print(response)
