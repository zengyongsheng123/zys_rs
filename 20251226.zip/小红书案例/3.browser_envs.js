function get_enviroment(proxy_array) {
    for (var i = 0; i < proxy_array.length; i++) {
        handler = '{\n' +
            '    get: function(target, property, receiver) {\n' +
            '        console.log("方法:", "get  ", "对象:", ' +
            '"' + proxy_array[i] + '" ,' +
            '"  属性:", property, ' +
            '"  属性类型:", ' + 'typeof property, ' +
            // '"  属性值:", ' + 'target[property], ' +
            '"  属性值类型:", typeof target[property]);\n' +
            // 'if (typeof target[property] == "undefined"){debugger}' +
            '        return target[property];\n' +
            '    },\n' +
            '    set: function(target, property, value, receiver) {\n' +
            '        console.log("方法:", "set  ", "对象:", ' +
            '"' + proxy_array[i] + '" ,' +
            '"  属性:", property, ' +
            '"  属性类型:", ' + 'typeof property, ' +
            // '"  属性值:", ' + 'target[property], ' +
            '"  属性值类型:", typeof target[property]);\n' +
            '        return Reflect.set(...arguments);\n' +
            '    }\n' +
            '}'
        eval('try{\n' + proxy_array[i] + ';\n'
            + proxy_array[i] + '=new Proxy(' + proxy_array[i] + ', ' + handler + ')}catch (e) {\n' + proxy_array[i] + '={};\n'
            + proxy_array[i] + '=new Proxy(' + proxy_array[i] + ', ' + handler + ')}')
    }
}

proxy_array = ['global', 'globalThis', 'window', 'document', 'location', 'navigator', 'history', 'screen']

window = global
window.addEventListener = function (){}
window.Screen = function () {}
window.MouseEvent = function () {}
window.window = window.top = window.self = window

function XMLHttpRequest() {
    
}


XMLHttpRequest.prototype.open = function () {
};
XMLHttpRequest.prototype.send = function () {
};
XMLHttpRequest.prototype.setRequestHeader = function () {
};
XMLHttpRequest.prototype.addEventListener = function () {
};
window.XMLHttpRequest = XMLHttpRequest;




function Navigator() {}
Navigator.prototype.webdriver = false
Navigator.prototype.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"

navigator = new Navigator()

window.Navigator = Navigator


function Element() {}
Element.prototype.getAttribute = function () {}
Element.prototype.removeChild = function () {}

function Document() {

}
Document.prototype.addEventListener = function () {}
Document.prototype.body = new Element()
Document.prototype.cookie = ''
Document.prototype.all = new Element()
Document.prototype.documentElement = new Element()
Document.prototype.getElementsByTagName = function (args) {
    console.log('getElementsByTagName获取的参数:', args)
    return []
}



document = new Document()

get_enviroment(['document.documentElement', 'window.addEventListener'])

location = {
    "ancestorOrigins": {},
    "href": "https://www.xiaohongshu.com/explore",
    "origin": "https://www.xiaohongshu.com",
    "protocol": "https:",
    "host": "www.xiaohongshu.com",
    "hostname": "www.xiaohongshu.com",
    "port": "",
    "pathname": "/explore",
    "search": "",
    "hash": ""
}

// get_enviroment(proxy_array)
