require('./3.browser_envs')
require('./4.source_code_1')
require('./5.source_code_2')
const {b64Encode, encodeUtf8} = require('./6.encrypt_function')

var crypto_js = require('crypto-js')


var e = "/api/sns/web/v1/homefeed"
var a = {
    "cursor_score": "",
    "num": 31,
    "refresh_type": 1,
    "note_index": 28,
    "unread_begin_note_id": "",
    "unread_end_note_id": "",
    "unread_note_count": 0,
    "category": "homefeed.food_v3",
    "search_key": "",
    "need_num": 6,
    "image_formats": [
        "jpg",
        "webp",
        "avif"
    ],
    "need_filter_image": false
}

function seccore_signv2(e, a) {
    var r = window.toString
        , c = e;
    "[object Object]" === r.call(a) || "[object Array]" === r.call(a) || (void 0 === a ? "undefined" : (0,
        h._)(a)) === "object" && null !== a ? c += JSON.stringify(a) : "string" == typeof a && (c += a);
    var d = crypto_js.MD5([c].join("")).toString()
        // var d = (0, p.Pu)([c].join(""))
        , s = window.mnsv2(c, d)
        , f = {
            x0: "4.2.6",
            x1: "xhs-pc-web",
            x2: "Windows",
            x3: s,
            x4: 'object'
        };
    return "XYS_" + b64Encode(encodeUtf8(JSON.stringify(f)))
}

console.log(seccore_signv2(e, a));
