#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import requests
import json


headers = {
    "accept": "application/json, text/plain, */*",
    "accept-language": "zh-CN,zh;q=0.9",
    "cache-control": "no-cache",
    "content-type": "application/json;charset=UTF-8",
    "origin": "https://www.xiaohongshu.com",
    "pragma": "no-cache",
    "priority": "u=1, i",
    "referer": "https://www.xiaohongshu.com/",
    "sec-ch-ua": "\"Google Chrome\";v=\"143\", \"Chromium\";v=\"143\", \"Not A(Brand\";v=\"24\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36",
    "x-b3-traceid": "54e407e5d7312fab",
    "x-s": "XYS_2UQhPsHCH0c1Pjh9HjIj2erjwjQhyoPTqBPT49pjHjIj2eHjwjQgynEDJ74AHjIj2ePjwjQTJdPIPAZlg98yGLTl4gYwLaT+GnrFnpb1JUR9p7phcFQ6pn8awepnJLTx2bSkzLDUyfE++7iF8rM9wgWhqnlgLLkNLgSI+b8My0p3JLbkz/ZIab4FzA8o8oZE+MQELaRlL7S8pnh6cDRQt7+LnoiharTEJ74dG9SLcLzmPrkHaMY/8MYnzMz6Pn8+c9EIqMQCLDkcpnbLP9I7/LT/Jfznnfl0yLLIaSQQyAmOarGROaHVHdWFH0ijJ9Qx8n+FHdF=",
    "x-s-common": "2UQAPsHC+aIjqArjwjHjNsQhPsHCH0rjNsQhPaHCH0c1Pjh9HjIj2eHjwjQgynEDJ74AHjIj2ePjwjQhyoPTqBPT49pjHjIj2ecjwjHMN0Z1+UHVHdWMH0ijP/SjP0qUPBG7+/bdy7ZEJ7Sl4ob0+nMD2fhh49MSP/Z74dDA47mxPgZMPeZIPeql+0HhPjHVHdW9H0ijHjIj2eqjwjHjNsQhwsHCHDDAwoQH8B4AyfRI8FS98g+Dpd4daLP3JFSb/BMsn0pSPM87nrldzSzQ2bPAGdb7zgQB8nph8emSy9E0cgk+zSS1qgzianYt8p+1/LzN4gzaa/+NqMS6qS4HLozoqfQnPbZEp98QyaRSp9P98pSl4oSzcgmca/P78nTTL08z/sVManD9q9z1J9p/8db8aob7JeQl4epsPrz6agW3Lr4ryaRApdz3agYDq7YM47HFqgzkanYMGLSbP9LA/bGIa/+nprSe+9LI4gzVPDbrJg+P4fprLFTALMm7+LSb4d+kpdzt/7b7wrQM498cqBzSpr8g/FSh+bzQygL9nSm7qSmM4epQ4flY/BQdqA+l4oYQ2BpAPp87arS34nMQyFSE8nkdqMD6pMzd8/4SL7bF8aRr+7+rG7mkqBpD8pSUzozQcA8Szb87PDSb/d+/qgzVJfl/4LExpdzQ4fRSy7bFP9+y+7+nJAzdaLp/2LSizgbwJdbMagYiJdbCwB4QyFSfJ7b7yFSenS4o+A+A8BlO8p8c4A+Q4DbSPB8d8ncIyFkQy/pAPFSUz0QM4rbQyLTAynz98nTy/fpLLocFJDbO8p4c4FpQ4S+IG/m98n8n4MYPJfpAzb87JFDAzgQQ2rLM/op749bl4UTU8nTinDbw8/b+/fLILoqEaL+wqM8PJ9p/GDSBanT6qM+U+7+nJD8kanTdqM8n4rMQygpDqgb7t7zl4b4QPAmSPMm7aLSiJ9LA4gclanSOq9kM4e+74gz1qMm7nrSeG9lQPFSUP04VyAQQ+nLl4gzeaLp/NFSbadPILoz1qbSQcLuIafp88DclaLpULrRc4rT6qgqAa/+O8gYl4b4z/epSyn+mqA+Iyo4QyBRAPASOqA+M4o+0Lo4YaL+tqM4c4ApQyn4Sy9pl/rSea9px8sRA8SmF+LSh+7+h4g4r+BMrJDSkG0zQ2rESPUuIqMzY4d+DanpSyMm7cDSiL7YQcFGMNMm7cFSkzr4Q2epSPem3arlr8BL94g4+agYPy7bn4URTqDbSPnH7qAml49pS4gzya/+0cFSezrYspdqFt7pFaFDA+nLI2drRHjIj2eDjwjFM+eHIP0c9+AHVHdWlPsHCPsIj2erlH0ijJfRUJnbVHdF=",
    "x-t": "1765975570745",
    "x-xray-traceid": "cd962c5c89f06e404dcc2f6ee05febfe",
    "xy-direction": "59"
}
cookies = {
    "a1": "19b2720f751gkp9oyqtqc5mdzn8wme107vy3wpj1p50000716282",
    "webId": "dad4aa83cbc5735d4fb86a55a6fdd942",
    "gid": "yjDJWJy8iDWWyjDJWJ8iWhUV2ykTUjlvA9ASvyU26fuIYq28E6dy8E888WyKJYJ8K42yKSdK",
    "abRequestId": "dad4aa83cbc5735d4fb86a55a6fdd942",
    "web_session": "030037ae7204e1ce52bed916392e4a38d6a4bc",
    "xsecappid": "xhs-pc-web",
    "webBuild": "5.0.7",
    "loadts": "1765975550055",
    "acw_tc": "0a50861f17659755639861556e1c41ea6f34f551af9e0a50157c65812a7ad6",
    "websectiga": "29098a4cf41f76ee3f8db19051aaa60c0fc7c5e305572fec762da32d457d76ae",
    "sec_poison_id": "f63abb71-189c-45a3-b130-696fda228477",
    "unread": "{%22ub%22:%22691ebb74000000001e034186%22%2C%22ue%22:%22693507c2000000001d03d6d7%22%2C%22uc%22:29}"
}
url = "https://edith.xiaohongshu.com/api/sns/web/v1/homefeed"
data = {
    "cursor_score": "",
    "num": 31,
    "refresh_type": 1,
    "note_index": 34,
    "unread_begin_note_id": "",
    "unread_end_note_id": "",
    "unread_note_count": 0,
    "category": "homefeed_recommend",
    "search_key": "",
    "need_num": 6,
    "image_formats": [
        "jpg",
        "webp",
        "avif"
    ],
    "need_filter_image": False
}
data = json.dumps(data, separators=(',', ':'))
response = requests.post(url, headers=headers, cookies=cookies, data=data)

print(response.text)
print(response)