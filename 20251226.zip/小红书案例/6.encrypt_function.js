var c = [
    "Z",
    "m",
    "s",
    "e",
    "r",
    "b",
    "B",
    "o",
    "H",
    "Q",
    "t",
    "N",
    "P",
    "+",
    "w",
    "O",
    "c",
    "z",
    "a",
    "/",
    "L",
    "p",
    "n",
    "g",
    "G",
    "8",
    "y",
    "J",
    "q",
    "4",
    "2",
    "K",
    "W",
    "Y",
    "j",
    "0",
    "D",
    "S",
    "f",
    "d",
    "i",
    "k",
    "x",
    "3",
    "V",
    "T",
    "1",
    "6",
    "I",
    "l",
    "U",
    "A",
    "F",
    "M",
    "9",
    "7",
    "h",
    "E",
    "C",
    "v",
    "u",
    "R",
    "X",
    "5"
]

function tripletToBase64(e) {
    return c[e >> 18 & 63] + c[e >> 12 & 63] + c[e >> 6 & 63] + c[63 & e]
}

function encodeChunk(e, a, r) {
    for (var c, d = [], f = a; f < r; f += 3)
        c = (e[f] << 16 & 0xff0000) + (e[f + 1] << 8 & 65280) + (255 & e[f + 2]),
            d.push(tripletToBase64(c));
    return d.join("")
}

function b64Encode(e) {
    for (var a, r = e.length, d = r % 3, f = [], s = 16383, u = 0, _ = r - d; u < _; u += s)
        f.push(encodeChunk(e, u, u + s > _ ? _ : u + s));
    return 1 === d ? (a = e[r - 1],
        f.push(c[a >> 2] + c[a << 4 & 63] + "==")) : 2 === d && (a = (e[r - 2] << 8) + e[r - 1],
        f.push(c[a >> 10] + c[a >> 4 & 63] + c[a << 2 & 63] + "=")),
        f.join("")
}

function encodeUtf8(e) {
    for (var a = encodeURIComponent(e), r = [], c = 0; c < a.length; c++) {
        var d = a.charAt(c);
        if ("%" === d) {
            var f = parseInt(a.charAt(c + 1) + a.charAt(c + 2), 16);
            r.push(f),
                c += 2
        } else
            r.push(d.charCodeAt(0))
    }
    return r
}

// 函数导出
module.exports = {b64Encode: b64Encode, encodeUtf8: encodeUtf8}