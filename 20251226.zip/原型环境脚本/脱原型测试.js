var bodavm = {
    "toolsFunc": {}, //功能函数相关,插件
    "envFunc": {},//环境相关
    "config": {},   //配置相关
    "memory": {},
    "toolsPlugin": {} //Plugin相关
}
!function () {
    bodavm.toolsFunc.setProto = function setpro(dom) {
        //设置原型链
        let ele = {}
        let tagpro = dom.toUpperCase()
        switch (tagpro) {
            case "DIV":
                Object.setPrototypeOf(ele, HTMLDivElement.prototype)
                return ele
            case "SCRIPT":
                Object.setPrototypeOf(ele, HTMLScriptElement.prototype)

                return ele
            case "TITLE":
                Object.setPrototypeOf(ele, HTMLTitleElement.prototype)

                return ele
            case "HEAD":
                Object.setPrototypeOf(ele, HTMLHeadElement.prototype)

                return ele
            case 'META':
                Object.setPrototypeOf(ele, HTMLMetaElement.prototype)

                return ele
            case 'LINK':
                Object.setPrototypeOf(ele, HTMLLinkElement.prototype)

                return ele
            case "A":
                Object.setPrototypeOf(ele, HTMLAnchorElement.prototype)

                return ele
            case "SPAN":
                Object.setPrototypeOf(ele, HTMLSpanElement.prototype)

                return ele
            case "P":
                Object.setPrototypeOf(ele, HTMLParagraphElement.prototype)

                return ele
            case "LI":
                Object.setPrototypeOf(ele, HTMLLIElement.prototype)

                return ele
            case "UL":
                Object.setPrototypeOf(ele, HTMLUListElement.prototype)

                return ele
            case 'IFRAME':
                Object.setPrototypeOf(ele, HTMLIFrameElement.prototype)

                return ele
            case 'IMG':
                Object.setPrototypeOf(ele, HTMLImageElement.prototype)

                return ele
            case "H1":
                Object.setPrototypeOf(ele, HTMLHeadingElement.prototype)

                return ele
            case "H2":
                Object.setPrototypeOf(ele, HTMLHeadingElement.prototype)

                return ele
            case "NOSCRIPT":
                Object.setPrototypeOf(ele, HTMLElement.prototype)

                return ele
            case 'INPUT':
                Object.setPrototypeOf(ele, HTMLInputElement.prototype)

                return ele
            case 'FORM':
                Object.setPrototypeOf(ele, HTMLFormElement.prototype)

                return ele
            case 'STYLE':
                Object.setPrototypeOf(ele, HTMLStyleElement.prototype)

                return ele
            case 'VIDEO':
                Object.setPrototypeOf(ele, HTMLVideoElement.prototype)
                return ele
            case 'BODY':
                Object.setPrototypeOf(ele, HTMLBodyElement.prototype)
                return ele
            case 'HTML':
                Object.setPrototypeOf(ele, HTMLHtmlElement.prototype)
                return ele
            case "CANVAS":
                Object.setPrototypeOf(ele, HTMLCanvasElement.prototype)
                return ele
            case "SECTION":
                Object.setPrototypeOf(ele, HTMLElement.prototype)
                return ele
            case "I":
                Object.setPrototypeOf(ele, HTMLElement.prototype)

                return ele
            case "FONT":
                Object.setPrototypeOf(ele, HTMLFontElement.prototype)

                return ele
            case "EM":
                Object.setPrototypeOf(ele, HTMLElement.prototype)

                return ele
            case "H6":
                Object.setPrototypeOf(ele, HTMLHeadingElement.prototype)

                return ele
            case "OPTION":
                Object.setPrototypeOf(ele, HTMLOptionElement.prototype)

                return ele
            case "SELECT":
                Object.setPrototypeOf(ele, HTMLSelectElement.prototype)

                return ele
            case "BR":
                Object.setPrototypeOf(ele, HTMLBRElement.prototype)

                return ele
            case "CLOB":
                Object.setPrototypeOf(ele, HTMLUnknownElement.prototype)

                return ele
            case "MARQUEE":
                Object.setPrototypeOf(ele, HTMLMarqueeElement.prototype)

                return ele
            case "STRONG":
                Object.setPrototypeOf(ele, HTMLElement.prototype)

                return ele
            case "BUTTON":
                Object.setPrototypeOf(ele, HTMLButtonElement.prototype)

                return ele
            case 'LEGEND':
                Object.setPrototypeOf(ele, HTMLLegendElement.prototype)

                return ele
            case 'OPTGROUP':
                Object.setPrototypeOf(ele, HTMLOptGroupElement.prototype)

                return ele
            case "FIELDSET":
                Object.setPrototypeOf(ele, HTMLFieldSetElement.prototype)

                return ele
            default:
                console.log(`setProto属性${tagpro}未实现`)
                break;
        }
    }
    //解析url
    bodavm.toolsFunc.parseUrl = function parseUrl(str) {
        if (!parseUrl || !parseUrl.options) {
            parseUrl.options = {
                strictMode: false,
                key: ["href", "protocol", "host", "userInfo", "user", "password", "hostname", "port", "relative", "pathname", "directory", "file", "search", "hash"],
                q: {
                    name: "queryKey",
                    parser: /(?:^|&)([^&=]*)=?([^&]*)/g
                },
                parser: {
                    strict: /^(?:([^:\/?#]+):)?(?:\/\/((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?))?((((?:[^?#\/]*\/)*)([^?#]*))(?:\?([^#]*))?(?:#(.*))?)/,
                    loose: /^(?:(?![^:@]+:[^:@\/]*@)([^:\/?#.]+):)?(?:\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/
                }
            };
        }
        if (!str) {
            return '';
        }
        var o = parseUrl.options,
            m = o.parser[o.strictMode ? "strict" : "loose"].exec(str),
            urlJson = {},
            i = 14;
        while (i--) urlJson[o.key[i]] = m[i] || "";
        urlJson[o.q.name] = {};
        urlJson[o.key[12]].replace(o.q.parser, function ($0, $1, $2) {
            if ($1) urlJson[o.q.name][$1] = $2;
        });
        delete urlJson["queryKey"];
        delete urlJson["userInfo"];
        delete urlJson["user"];
        delete urlJson["password"];
        delete urlJson["relative"];
        delete urlJson["directory"];
        delete urlJson["file"];
        urlJson["protocol"] += ":";
        urlJson["origin"] = urlJson["protocol"] + "//" + urlJson["host"];
        urlJson["search"] = urlJson["search"] && "?" + urlJson["search"];
        urlJson["hash"] = urlJson["hash"] && "#" + urlJson["hash"];
        return urlJson;
    }
    //获取原型对象上自身属性值
    bodavm.toolsFunc.getProtoAttr = function getProtoAttr(key) {
        return this[bodavm.memory.symbolData] && this[bodavm.memory.symbolData][key];
    }
    bodavm.toolsFunc.setProtoAttr = function setProtoAttr(key, value) {
        if (!(bodavm.memory.symbolData in this)) {
            Object.defineProperty(this, bodavm.memory.symbolData, {
                enumerable: false,
                configurable: false,
                writable: true,
                value: {},
            }),
                Object.defineProperty(this, bodavm.memory.symbolProperty, {
                    value: 1,
                    enumerable: false,
                    writable: false,
                    configurable: false
                })

        }
        this[bodavm.memory.symbolData][key] = value;
    }
    //获取对象类型
    bodavm.toolsFunc.getType = function getType(obj) {
        return Object.prototype.toString.call(obj);
    }
    //过滤代理属性
    bodavm.toolsFunc.filterProxyProp = function filterProxyProp(prop) {
        for (let i = 0; i < bodavm.memory.filterProxyProp.length; i++) {
            if (bodavm.memory.filterProxyProp[i] === prop) {
                return true;
            }
        }
        return false
    }
    // proxy代理
    bodavm.toolsFunc.proxy = function (obj, objName) {
        // bodavm.toolsFunc.symbolProperty(obj)
        bodavm.memory.globalobj[objName] = obj
        if (bodavm.config.proxy == false) {
            return obj
        }
        ;
        if (bodavm.memory.symbolProxy in obj) {// 判断对象obj是否是已代理的对象
            return obj[bodavm.memory.symbolProxy];
        }
        let handler = {
            get(target, prop, receiver) {
                if (prop == '_createHelper') {
                    debugger
                }
                if (prop == 'onmessage') {
                    debugger
                }
                let result = Reflect.get(target, prop, receiver)

                // if (target ==window.$_ts._$Aw){return result }
                if (bodavm.toolsFunc.filterProxyProp(prop)) {
                    return result;
                }
                if (prop == hasOwnProperty) {
                    debugger
                }
                // let mylog=
                console.log('[' + objName + ']', '   获取属性:   ', prop, '   value:   ', result);

                if (typeof result == 'function') {
                    myloglist.push({'type': 'get:' + objName, 'prop0': prop, 'prop1': result.toString()})

                } else {
                    myloglist.push({'type': 'get:' + objName, 'prop0': prop, 'prop1': result})

                }


                if (result instanceof Object) {
                    // bodavm.toolsFunc.symbolProperty(result)

                    return bodavm.toolsFunc.proxy(result, `${objName} -> ${prop.toString()}`)
                }

                return result;
            },
            set(target, propKey, value, receiver) {
                // debugger
                if (objName == 'window' && propKey) {
                    bodavm.memory.window[propKey] = value
                }
                console.log('[' + objName + ']', "   设置属性:   ", propKey, "   value:   ", value);
                if (typeof value == 'function') {
                    myloglist.push({'type': 'set:' + objName, 'prop0': propKey, 'prop1': value.toString()})

                } else {
                    if (!value) {
                        myundefinedlist.push({'type': 'set:' + objName, 'prop0': propKey, 'prop1': value})

                    }
                    myloglist.push({'type': 'set:' + objName, 'prop0': propKey, 'prop1': value})
                }

                let res = Reflect.set(target, propKey, value, receiver);
                // bodavm.toolsFunc.symbolProperty(res)
                return res
            }
        };
        // debugger
        let proxyObj = new Proxy(obj, handler);
        Object.defineProperty(obj, bodavm.memory.symbolProxy, {
            configurable: false,
            enumerable: false,
            writable: false,
            value: proxyObj
        });
        return proxyObj;
    }
    bodavm.toolsFunc.dispatch = function dispatch(self, obj, objName, funcName, argList, defaultValue) {
        //obj Document.prototype
        //obj loction
        // debugger
        //bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","write",arguments)}});
        let name = `${objName}_${funcName}`
        //实现r={} ,r.__proto__=Document.prototype ,r.location 报错

        //实现Document.prototype.activeElement()调用报错
        if (Object.getOwnPropertyDescriptor(obj, "constructor") !== undefined) {
            if (Object.getOwnPropertyDescriptor(self, "constructor") !== undefined) {
                return bodavm.toolsFunc.throwError("TypeError", "Illegal invocation")
            }
        }
        try {

            if (bodavm.config.issymbolProperty) {
                if (self[bodavm.memory.symbolProperty] == undefined) {
                    debugger
                    console.log(self, `  bodavm.toolsFunc.dispatch1 执行出错`, funcName);
                    return bodavm.toolsFunc.throwError("TypeError", "Illegal invocation")

                }
                //实现r={} ;r.__proto__=document ,r.location 报错
                if (self.__proto__.constructor == self.__proto__.__proto__.constructor) {
                    debugger
                    console.log(self, `  bodavm.toolsFunc.dispatch2  执行出错`, funcName);
                    return bodavm.toolsFunc.throwError("TypeError", "Illegal invocation")
                }

            }

            return bodavm.envFunc[name].apply(self, argList)


        } catch (e) {
            //
            // debugger
            let log__ = `'[${name}]正在执行,错误信息${e.message}'`
            console.log(log__);
            bodavm.toolsFunc.printLog(log__)
        }
    }
    //定义对象属性 defineProperty
    bodavm.toolsFunc.defineProperty = function defineProperty(obj, prop, OldDescriptior) {
        // if (obj ==window){debugger}
        let newDescriptior = {};
        newDescriptior.configurable = bodavm.config.proxy || OldDescriptior.configurable;//如果开启代理必须是true
        newDescriptior.enumerable = OldDescriptior.enumerable;
        if (OldDescriptior.hasOwnProperty("writable")) {
            newDescriptior.writable = bodavm.config.proxy || OldDescriptior.writable;//如果开启代理必须是true
        }
        if (OldDescriptior.hasOwnProperty("value")) {
            let value = OldDescriptior.value;
            if (typeof value == "function") {
                bodavm.toolsFunc.safeFunc(value, prop)
            }
            newDescriptior.value = value;
        }
        if (OldDescriptior.hasOwnProperty("get")) {
            let get = OldDescriptior.get;
            if (typeof get == "function") {
                bodavm.toolsFunc.safeFunc(get, `get ${prop}`)
            }
            newDescriptior.get = get;
        }
        if (OldDescriptior.hasOwnProperty("set")) {
            let set = OldDescriptior.set;
            if (typeof set == "function") {
                bodavm.toolsFunc.safeFunc(set, `set ${prop}`)
            }
            newDescriptior.set = set;
        }
        Object.defineProperty(obj, prop, newDescriptior)

    };
    //保护函数
    (() => {
        "use strict";
        const $toString = Function.toString;  //hook Function.toString 且命名为myToString
        //变量名取随机数防检测
        const myFunction_toString_symbol = Symbol('('.concat('', ')_', (Math.random() + '').toString(36)));

        //自定义函数
        //逻辑与短路运算      &&    如果表达式1结果为真,则返回表达式2,
        //逻辑或短路运算      ||    如果表达式1结果为真,则返回表达式1,
        //1 && 0 || 3    3

        /*如果this的类型为function 则返回this[myFunction_toString_symbol]
        然后判断this[myFunction_toString_symbol]是否为真,
        为真则返回this[myFunction_toString_symbol]的结果.
        */

        //如果this的类型不是function,则直接返回$toString.call(this)

        //$toString.call(this)就是对原函数调用

        const myToString = function () {
            return typeof this == 'function' && this[myFunction_toString_symbol] || $toString.call(this);   //谁调用这个方法,this就是谁,比如boda调用,这个this就是boda
        };


        function set_native(func, key, value) {
            //定义描述符
            Object.defineProperty(func, key, {
                "enumerable": false,
                "configurable": true,
                "writable": true,
                "value": value
            })
        };
        delete Function.prototype['toString']; //删除原型链上的toString
        set_native(Function.prototype, "toString", myToString); //自己定义个getter方法

        //myToString的 myFunction_toString_symbol属性设置为  function toString() { [native code] }
        //myFunction_toString_symbol= function toString() { [native code] }
        set_native(Function.prototype.toString, myFunction_toString_symbol, "function toString() { [native code] }"); //套个娃 保护一下我们定义的toString 否则就暴露了


        bodavm.toolsFunc.safefunction = (func, name) => {
            set_native(func, myFunction_toString_symbol, `function ${myFunction_toString_symbol, name || ''}() { [native code] }`);
            set_native(func, 'name', `${myFunction_toString_symbol, name || ''}`);
            // }
        }; //导出函数到globalThis
    }).call(this);
    //对象重命名
    bodavm.toolsFunc.reNameObj = function reNameObj(obj, obname) {
        Object.defineProperty(obj.prototype, Symbol.toStringTag, {
            value: obname,
            configurable: true,
            writable: false,
            enumerable: false
        })
    };
    //函数重命名
    bodavm.toolsFunc.reNameFunc = function reNameFunc(func, name) {
        Object.defineProperty(func, "name", {
            value: name,
            configurable: true,
            writable: false,
            enumerable: false
        })
    }
    //合并 保护方法
    bodavm.toolsFunc.safeFunc = function safeFunc(func, name) {
        bodavm.toolsFunc.safefunction(func, name)
        bodavm.toolsFunc.reNameFunc(func, name)
    }
    //合并 保护原型
    bodavm.toolsFunc.safeProto = function safeProto(obj, name) {
        bodavm.memory.globalobj[name] = obj
        // bodavm.toolsFunc.symbolProperty(obj)
        bodavm.toolsFunc.safefunction(obj, name)
        bodavm.toolsFunc.reNameObj(obj, name)
    }
    //抛错
    bodavm.toolsFunc.throwError = function throwError(name, message) {
        let e = new Error();
        e.message = message;
        e.name = name;
        e.stack = `${name}: ${message}at <anonymous>:1:1`
        throw e
    }
    // base64编码解码
    bodavm.toolsFunc.base64 = {};
    bodavm.toolsFunc.base64.base64EncodeChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    bodavm.toolsFunc.base64.base64DecodeChars = new Array(-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1);
    bodavm.toolsFunc.base64.base64encode = function base64encode(str) {
        var out, i, len;
        var c1, c2, c3;

        len = str.length;
        i = 0;
        out = "";
        while (i < len) {
            c1 = str.charCodeAt(i++) & 0xff;
            if (i == len) {
                out += bodavm.toolsFunc.base64.base64EncodeChars.charAt(c1 >> 2);
                out += bodavm.toolsFunc.base64.base64EncodeChars.charAt((c1 & 0x3) << 4);
                out += "==";
                break;
            }
            c2 = str.charCodeAt(i++);
            if (i == len) {
                out += bodavm.toolsFunc.base64.base64EncodeChars.charAt(c1 >> 2);
                out += bodavm.toolsFunc.base64.base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
                out += bodavm.toolsFunc.base64.base64EncodeChars.charAt((c2 & 0xF) << 2);
                out += "=";
                break;
            }
            c3 = str.charCodeAt(i++);
            out += bodavm.toolsFunc.base64.base64EncodeChars.charAt(c1 >> 2);
            out += bodavm.toolsFunc.base64.base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
            out += bodavm.toolsFunc.base64.base64EncodeChars.charAt(((c2 & 0xF) << 2) | ((c3 & 0xC0) >> 6));
            out += bodavm.toolsFunc.base64.base64EncodeChars.charAt(c3 & 0x3F);
        }
        ;
        console.log(`bs64编码:${str}`, `编码后${out}`);
        return out;
    }
    bodavm.toolsFunc.base64.base64decode = function base64decode(str) {
        var c1, c2, c3, c4;
        var i, len, out;

        len = str.length;
        i = 0;
        out = "";
        while (i < len) {
            /* c1 */
            do {
                c1 = bodavm.toolsFunc.base64.base64DecodeChars[str.charCodeAt(i++) & 0xff];
            } while (i < len && c1 == -1);
            if (c1 == -1)
                break;

            /* c2 */
            do {
                c2 = bodavm.toolsFunc.base64.base64DecodeChars[str.charCodeAt(i++) & 0xff];
            } while (i < len && c2 == -1);
            if (c2 == -1)
                break;

            out += String.fromCharCode((c1 << 2) | ((c2 & 0x30) >> 4));

            /* c3 */
            do {
                c3 = str.charCodeAt(i++) & 0xff;
                if (c3 == 61)
                    return out;
                c3 = bodavm.toolsFunc.base64.base64DecodeChars[c3];
            } while (i < len && c3 == -1);
            if (c3 == -1)
                break;

            out += String.fromCharCode(((c2 & 0XF) << 4) | ((c3 & 0x3C) >> 2));

            /* c4 */
            do {
                c4 = str.charCodeAt(i++) & 0xff;
                if (c4 == 61)
                    return out;
                c4 = bodavm.toolsFunc.base64.base64DecodeChars[c4];
            } while (i < len && c4 == -1);
            if (c4 == -1)
                break;
            out += String.fromCharCode(((c3 & 0x03) << 6) | c4);
        }
        return out;
    }
}();

// Document对象
Document = function Document(){}
// bodavm.toolsFunc.safeProto(Document,"Document");
// Object.setPrototypeOf(Document.prototype,Node.prototype);
bodavm.toolsFunc.defineProperty(Document,"parseHTMLUnsafe",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document,"Document","parseHTMLUnsafe",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"implementation",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","implementation_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"URL",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","URL_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"documentURI",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","documentURI_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"compatMode",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","compatMode_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"characterSet",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","characterSet_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"charset",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","charset_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"inputEncoding",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","inputEncoding_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"contentType",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","contentType_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"doctype",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","doctype_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"documentElement",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","documentElement_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"xmlEncoding",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","xmlEncoding_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"xmlVersion",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","xmlVersion_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","xmlVersion_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"xmlStandalone",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","xmlStandalone_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","xmlStandalone_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"domain",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","domain_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","domain_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"referrer",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","referrer_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"cookie",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","cookie_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","cookie_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"lastModified",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","lastModified_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"readyState",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","readyState_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"title",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","title_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","title_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"dir",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","dir_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","dir_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"body",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","body_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","body_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"head",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","head_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"images",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","images_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"embeds",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","embeds_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"plugins",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","plugins_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"links",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","links_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"forms",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","forms_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"scripts",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","scripts_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"currentScript",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","currentScript_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"defaultView",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","defaultView_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"designMode",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","designMode_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","designMode_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onreadystatechange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onreadystatechange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onreadystatechange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"anchors",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","anchors_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"applets",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","applets_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"fgColor",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","fgColor_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","fgColor_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"linkColor",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","linkColor_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","linkColor_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"vlinkColor",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","vlinkColor_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","vlinkColor_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"alinkColor",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","alinkColor_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","alinkColor_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"bgColor",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","bgColor_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","bgColor_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"all",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","all_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"scrollingElement",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","scrollingElement_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"onpointerlockchange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerlockchange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerlockchange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onpointerlockerror",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerlockerror_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerlockerror_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"hidden",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","hidden_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"visibilityState",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","visibilityState_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"wasDiscarded",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","wasDiscarded_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"prerendering",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","prerendering_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"featurePolicy",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","featurePolicy_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"webkitVisibilityState",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","webkitVisibilityState_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"webkitHidden",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","webkitHidden_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"onbeforecopy",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onbeforecopy_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onbeforecopy_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onbeforecut",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onbeforecut_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onbeforecut_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onbeforepaste",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onbeforepaste_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onbeforepaste_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onfreeze",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onfreeze_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onfreeze_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onprerenderingchange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onprerenderingchange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onprerenderingchange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onresume",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onresume_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onresume_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onsearch",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onsearch_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onsearch_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onvisibilitychange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onvisibilitychange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onvisibilitychange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"timeline",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","timeline_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"fullscreenEnabled",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","fullscreenEnabled_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","fullscreenEnabled_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"fullscreen",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","fullscreen_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","fullscreen_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onfullscreenchange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onfullscreenchange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onfullscreenchange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onfullscreenerror",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onfullscreenerror_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onfullscreenerror_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"webkitIsFullScreen",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","webkitIsFullScreen_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"webkitCurrentFullScreenElement",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","webkitCurrentFullScreenElement_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"webkitFullscreenEnabled",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","webkitFullscreenEnabled_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"webkitFullscreenElement",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","webkitFullscreenElement_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"onwebkitfullscreenchange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwebkitfullscreenchange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwebkitfullscreenchange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onwebkitfullscreenerror",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwebkitfullscreenerror_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwebkitfullscreenerror_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"rootElement",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","rootElement_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"pictureInPictureEnabled",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","pictureInPictureEnabled_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"onbeforexrselect",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onbeforexrselect_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onbeforexrselect_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onabort",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onabort_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onabort_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onbeforeinput",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onbeforeinput_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onbeforeinput_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onbeforematch",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onbeforematch_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onbeforematch_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onbeforetoggle",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onbeforetoggle_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onbeforetoggle_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onblur",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onblur_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onblur_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"oncancel",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncancel_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncancel_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"oncanplay",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncanplay_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncanplay_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"oncanplaythrough",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncanplaythrough_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncanplaythrough_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onchange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onchange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onchange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onclick",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onclick_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onclick_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onclose",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onclose_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onclose_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"oncommand",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncommand_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncommand_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"oncontentvisibilityautostatechange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncontentvisibilityautostatechange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncontentvisibilityautostatechange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"oncontextlost",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncontextlost_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncontextlost_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"oncontextmenu",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncontextmenu_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncontextmenu_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"oncontextrestored",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncontextrestored_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncontextrestored_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"oncuechange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncuechange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncuechange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ondblclick",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondblclick_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondblclick_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ondrag",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondrag_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondrag_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ondragend",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondragend_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondragend_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ondragenter",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondragenter_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondragenter_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ondragleave",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondragleave_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondragleave_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ondragover",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondragover_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondragover_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ondragstart",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondragstart_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondragstart_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ondrop",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondrop_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondrop_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ondurationchange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondurationchange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ondurationchange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onemptied",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onemptied_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onemptied_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onended",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onended_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onended_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onerror",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onerror_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onerror_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onfocus",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onfocus_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onfocus_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onformdata",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onformdata_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onformdata_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"oninput",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oninput_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oninput_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"oninvalid",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oninvalid_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oninvalid_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onkeydown",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onkeydown_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onkeydown_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onkeypress",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onkeypress_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onkeypress_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onkeyup",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onkeyup_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onkeyup_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onload",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onload_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onload_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onloadeddata",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onloadeddata_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onloadeddata_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onloadedmetadata",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onloadedmetadata_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onloadedmetadata_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onloadstart",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onloadstart_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onloadstart_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onmousedown",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmousedown_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmousedown_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onmouseenter",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmouseenter_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmouseenter_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onmouseleave",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmouseleave_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmouseleave_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onmousemove",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmousemove_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmousemove_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onmouseout",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmouseout_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmouseout_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onmouseover",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmouseover_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmouseover_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onmouseup",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmouseup_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmouseup_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onmousewheel",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmousewheel_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onmousewheel_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onpause",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpause_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpause_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onplay",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onplay_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onplay_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onplaying",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onplaying_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onplaying_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onprogress",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onprogress_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onprogress_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onratechange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onratechange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onratechange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onreset",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onreset_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onreset_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onresize",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onresize_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onresize_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onscroll",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onscroll_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onscroll_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onscrollend",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onscrollend_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onscrollend_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onsecuritypolicyviolation",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onsecuritypolicyviolation_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onsecuritypolicyviolation_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onseeked",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onseeked_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onseeked_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onseeking",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onseeking_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onseeking_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onselect",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onselect_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onselect_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onslotchange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onslotchange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onslotchange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onstalled",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onstalled_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onstalled_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onsubmit",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onsubmit_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onsubmit_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onsuspend",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onsuspend_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onsuspend_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ontimeupdate",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ontimeupdate_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ontimeupdate_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ontoggle",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ontoggle_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ontoggle_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onvolumechange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onvolumechange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onvolumechange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onwaiting",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwaiting_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwaiting_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onwebkitanimationend",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwebkitanimationend_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwebkitanimationend_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onwebkitanimationiteration",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwebkitanimationiteration_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwebkitanimationiteration_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onwebkitanimationstart",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwebkitanimationstart_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwebkitanimationstart_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onwebkittransitionend",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwebkittransitionend_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwebkittransitionend_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onwheel",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwheel_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onwheel_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onauxclick",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onauxclick_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onauxclick_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ongotpointercapture",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ongotpointercapture_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ongotpointercapture_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onlostpointercapture",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onlostpointercapture_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onlostpointercapture_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onpointerdown",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerdown_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerdown_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onpointermove",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointermove_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointermove_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onpointerup",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerup_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerup_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onpointercancel",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointercancel_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointercancel_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onpointerover",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerover_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerover_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onpointerout",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerout_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerout_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onpointerenter",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerenter_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerenter_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onpointerleave",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerleave_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerleave_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onselectstart",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onselectstart_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onselectstart_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onselectionchange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onselectionchange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onselectionchange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onanimationend",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onanimationend_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onanimationend_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onanimationiteration",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onanimationiteration_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onanimationiteration_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onanimationstart",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onanimationstart_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onanimationstart_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ontransitionrun",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ontransitionrun_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ontransitionrun_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ontransitionstart",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ontransitionstart_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ontransitionstart_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ontransitionend",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ontransitionend_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ontransitionend_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ontransitioncancel",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ontransitioncancel_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ontransitioncancel_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"oncopy",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncopy_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncopy_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"oncut",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncut_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","oncut_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onpaste",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpaste_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpaste_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"children",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","children_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"firstElementChild",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","firstElementChild_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"lastElementChild",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","lastElementChild_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"childElementCount",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","childElementCount_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"activeElement",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","activeElement_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"styleSheets",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","styleSheets_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"pointerLockElement",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","pointerLockElement_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"fullscreenElement",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","fullscreenElement_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","fullscreenElement_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"adoptedStyleSheets",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","adoptedStyleSheets_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","adoptedStyleSheets_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"pictureInPictureElement",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","pictureInPictureElement_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"fonts",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","fonts_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"adoptNode",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","adoptNode",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"append",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","append",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"captureEvents",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","captureEvents",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"caretPositionFromPoint",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","caretPositionFromPoint",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"caretRangeFromPoint",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","caretRangeFromPoint",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"clear",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","clear",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"close",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","close",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createAttribute",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createAttribute",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createAttributeNS",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createAttributeNS",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createCDATASection",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createCDATASection",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createComment",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createComment",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createDocumentFragment",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createDocumentFragment",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createElement",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createElement",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createElementNS",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createElementNS",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createEvent",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createEvent",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createExpression",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createExpression",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createNSResolver",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createNSResolver",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createNodeIterator",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createNodeIterator",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createProcessingInstruction",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createProcessingInstruction",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createRange",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createRange",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createTextNode",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createTextNode",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"createTreeWalker",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","createTreeWalker",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"elementFromPoint",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","elementFromPoint",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"elementsFromPoint",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","elementsFromPoint",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"evaluate",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","evaluate",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"execCommand",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","execCommand",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"exitFullscreen",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","exitFullscreen",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"exitPictureInPicture",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","exitPictureInPicture",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"exitPointerLock",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","exitPointerLock",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"getAnimations",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","getAnimations",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"getElementById",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","getElementById",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"getElementsByClassName",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","getElementsByClassName",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"getElementsByName",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","getElementsByName",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"getElementsByTagName",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","getElementsByTagName",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"getElementsByTagNameNS",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","getElementsByTagNameNS",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"getSelection",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","getSelection",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"hasFocus",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","hasFocus",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"hasStorageAccess",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","hasStorageAccess",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"hasUnpartitionedCookieAccess",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","hasUnpartitionedCookieAccess",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"importNode",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","importNode",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"moveBefore",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","moveBefore",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"open",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","open",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"prepend",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","prepend",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"queryCommandEnabled",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","queryCommandEnabled",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"queryCommandIndeterm",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","queryCommandIndeterm",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"queryCommandState",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","queryCommandState",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"queryCommandSupported",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","queryCommandSupported",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"queryCommandValue",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","queryCommandValue",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"querySelector",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","querySelector",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"querySelectorAll",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","querySelectorAll",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"releaseEvents",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","releaseEvents",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"replaceChildren",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","replaceChildren",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"requestStorageAccess",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","requestStorageAccess",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"requestStorageAccessFor",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","requestStorageAccessFor",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"startViewTransition",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","startViewTransition",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"webkitCancelFullScreen",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","webkitCancelFullScreen",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"webkitExitFullscreen",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","webkitExitFullscreen",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"write",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","write",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"writeln",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","writeln",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"fragmentDirective",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","fragmentDirective_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"onpointerrawupdate",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerrawupdate_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onpointerrawupdate_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"browsingTopics",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","browsingTopics",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"hasPrivateToken",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","hasPrivateToken",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"hasRedemptionRecord",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","hasRedemptionRecord",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"activeViewTransition",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","activeViewTransition_get",arguments);}, set:undefined});
bodavm.toolsFunc.defineProperty(Document.prototype,"onscrollsnapchange",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onscrollsnapchange_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onscrollsnapchange_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"onscrollsnapchanging",{configurable:true, enumerable:true, get:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onscrollsnapchanging_get",arguments);}, set:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","onscrollsnapchanging_set",arguments);}});
bodavm.toolsFunc.defineProperty(Document.prototype,"ariaNotify",{configurable:true, enumerable:true, writable:true, value:function(){return bodavm.toolsFunc.dispatch(this,Document.prototype,"Document","ariaNotify",arguments);}});


// HTMLDocument对象
HTMLDocument = function HTMLDocument() {
    return bodavm.toolsFunc.throwError("'TypeError','Failed to construct 'HTMLDocument': Illegal constructor'");
}
// bodavm.toolsFunc.safeProto(HTMLDocument, "HTMLDocument");
Object.setPrototypeOf(HTMLDocument.prototype, Document.prototype);

// document对象
document = {}
Object.setPrototypeOf(document, HTMLDocument.prototype);
bodavm.toolsFunc.defineProperty(document, "location", {
    configurable: false, enumerable: true, get: function () {
        return bodavm.toolsFunc.dispatch(this, document, "document", "location_get", arguments);
    }, set: function () {
        return bodavm.toolsFunc.dispatch(this, document, "document", "location_set", arguments);
    }
});

console.log(Object.getOwnPropertyDescriptor(document, 'createElement'));
console.log(Object.getOwnPropertyDescriptor(document.__proto__.__proto__, 'createElement'));


