

bodaEnv.memory.document={
    URL:"https://passport.gds.org.cn/Account/Login",
    referrer:"",
    documentURI:"https://passport.gds.org.cn/Account/Login",
    compatMode:"CSS1Compat",
    dir:"",
    title:'中国商品信息服务平台',
    designMode:"off",
    readyState:"complete",
    contentType:"text/html",
    inputEncoding:"UTF-8",
    domain:"passport.gds.org.cn",
    characterSet:"UTF-8",
    charset:"UTF-8",
    hidden:"false",
    onmousemove:null,
    onselectionchange:null,
    cookie:''
    
};

bodaEnv.memory.cookies_=bodaEnv.memory.document['cookie'].split(';')
if (bodaEnv.memory.cookies_[0]){
    for (let i = 0; i < bodaEnv.memory.cookies_.length; i++) {
        let cookie = bodaEnv.memory.cookies_[i].split("=");
        bodaEnv.memory.jsonCookie[cookie[0]] = cookie[1];
      }
}



bodaEnv.memory.htmldivelement={
     align:"undefined",

};

bodaEnv.memory.history={
    scrollRestoration:"auto"
};

bodaEnv.memory.screen={
    pixelDepth:24,
    colorDepth:24,
    availLeft:0,
    availTop:0,
    isExtended:false,
    orientation:{},
    onchange:null,
};

bodaEnv.memory.navigator={
    language:"zh-CN",
    // userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    // appVerboda:"undefined",
    vendor:"Google Inc.",
    appName:"Netscape",
    appCodeName:"Mozilla",
    cookieEnabled:true,
    languages:["zh-CN","zh"],
    productSub:"20030107",
    userAgentData:{"brands":[{"brand":"Not A(Brand","version":"99"},{"brand":"Google Chrome","version":"121"},{"brand":"Chromium","version":"121"}],"mobile":false,"platform":"Windows"},
    xr:{},
    platform:'Win32',
    webkitPersistentStorage:{},
    connection:{},
    javaEnabled:false,
    product:'Gecko',
    vendorSub:"",
    deviceMemory:8,
    maxTouchPoints:0
};
bodaEnv.memory.window={
    vilame_setter:[{"domain":"passport.gds.org.cn","hostOnly":true,"httpOnly":true,"name":".AspNetCore.Antiforgery.d6pkaya9xoc","path":"/","sameSite":"strict","secure":false,"session":true,"storeId":"0","value":"CfDJ8JaymALTRoRGvEP87ZWqRWvt52HJZW6ROkVOBXRDVWxz5DHHREAoExGisno0QSHAPsdQohDkQ-s_Cs1LvNj7sgOfZnFhBfmGad11XSFopK4KvRonDKEN0C-N5w16t-kPMeXhOHkWjUEshxfIujA2q90"},{"domain":".gds.org.cn","expirationDate":1723814910,"hostOnly":false,"httpOnly":false,"name":"tfstk","path":"/","sameSite":"unspecified","secure":false,"session":false,"storeId":"0","value":"eClDc3OTWxyb6MCIymFXwUoxkbv-liN_mcCTX5EwUur7XEZYDVoiS2yZDhZxEc0iARlxWSP7jco5HRETgUiiYm2tjVTb7loZjlHveB3jl5NwvcAp9qwXFI0Dv4yMESN__HKJ9B3jl5i3RxbdXqg2Zs1A_B0-ZaNO_1ly1-qnuOCN_b40ntg4qq3xZr20YgJFU9-Xp1ayWbW1C-z7rknO8TepADY62UYlLRw4PrRprUX1C-z7rkLkr9o_3za29"}],
    name:"",
    origin:"https://passport.gds.org.cn",
    defaultStatus:undefined,
    defaultstatus:undefined,
    devicePixelRatio:1.5,
    isSecureContext:true,
    length:0,
    status:"",
    onmessage:null,
    onbeforeunload:null,
    closed:false,
    isSecureContext:true,
    onappinstalled:null,
    onbeforeinstallprompt:null,
    onbeforexrselect:null,
    onabort:null,
    onblur:null,
    oncancel:null,
    oncanplay:null,
    oncanplaythrough:null,
    onsearch:null,
    opener:null,
    frameElement:null,
    // customElements:[object CustomElementRegistry]
    onbeforeinput:null,
        
    oncontextmenu:null,

    oncontextrestored:null,

    oncuechange:null,

    ondblclick:null,

    ondrag:null,

    ondragend:null,

    ondragenter:null,

    ondragleave:null,

    ondragover:null,

    ondragstart:null,

    ondrop:null,

    ondurationchange:null,

    onemptied:null,

    onended:null,

    onerror:null,

    onfocus:null,

    onformdata:null,

    oninput:null,

    oninvalid:null,

    onkeydown:null,

    onkeypress:null,

    onkeyup:null,

    onload:null,

    onloadeddata:null,

    onloadedmetadata:null,

    onloadstart:null,

    onmousedown:null,

    onmouseenter:null,

    onmouseleave:null,

    onmousemove:null,

    onmouseout:null,

    onmouseover:null,

    onmouseup:null,

    onmousewheel:null,

    onpause:null,

    onplay:null,

    onplaying:null,

    onprogress:null,

    onratechange:null,

    onreset:null,

    onresize:null,

    onscroll:null,

    onsecuritypolicyviolation:null,

    onseeked:null,

    onseeking:null,

    onselect:null,

    onslotchange:null,

    onstalled:null,

    onsubmit:null,

    onsuspend:null,

    ontimeupdate:null,

    ontoggle:null,

    onvolumechange:null,

    onwaiting:null,

    onwebkitanimationend:null,

    onwebkitanimationiteration:null,

    onwebkitanimationstart:null,

    onwebkittransitionend:null,

    onwheel:null,

    onauxclick:null,

    ongotpointercapture:null,

    onlostpointercapture:null,

    onpointerdown:null,

    onpointermove:null,

    onpointerrawupdate:null,

    onpointerup:null,

    onpointercancel:null,

    onpointerover:null,

    onpointerout:null,

    onpointerenter:null,

    onpointerleave:null,

    onselectstart:null,

    onselectionchange:null,

    onanimationend:null,

    onanimationiteration:null,

    onanimationstart:null,

    ontransitionrun:null,

    ontransitionstart:null,

    ontransitionend:null,

    ontransitioncancel:null,

    onafterprint:null,

    onbeforeprint:null,

    onbeforeunload:null,

    onhashchange:null,

    onlanguagechange:null,

    onmessage:null,

    onmessageerror:null,

    onoffline:null,

    ononline:null,

    onpagehide:null,

    onpageshow:null,

    onpopstate:null,

    onrejectionhandled:null,

    onstorage:null,

    onunhandledrejection:null,

    onunload:null,

    crossOriginIsolated:false,

    // scheduler:[object Scheduler],

    ondevicemotion:null,

    ondeviceorientation:null,

    ondeviceorientationabsolute:null,

    onbeforematch:null,

    onbeforetoggle:null,

    originAgentCluster:true,

    credentialless:false,

    oncontentvisibilityautostatechange:null,

    onscrollend:null,



};


bodaEnv.memory.localStorage={"ETLCD":"false","syfhs":"3210382984","lswucn":"G0442D070105A8790D6B677B13552462964109A2E2D7B8BC4A7@@1708262910","length":3}
delete bodaEnv.memory.localStorage['length']

bodaEnv.memory.Performance={
    'getEntriesByType':[{"name":"https://passport.gds.org.cn/lib/bootstrap/dist/css/bootstrap.css","entryType":"resource","startTime":364,"duration":336,"initiatorType":"link","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":364,"domainLookupStart":364,"domainLookupEnd":364,"connectStart":364,"secureConnectionStart":364,"connectEnd":364,"requestStart":410.70000000018626,"responseStart":443.5,"firstInterimResponseStart":0,"responseEnd":700,"transferSize":197470,"encodedBodySize":197170,"decodedBodySize":197170,"responseStatus":200,"serverTiming":[]},{"name":"https://passport.gds.org.cn/css/swiper.min.css","entryType":"resource","startTime":364.4000000001397,"duration":137.89999999990687,"initiatorType":"link","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":364.4000000001397,"domainLookupStart":364.4000000001397,"domainLookupEnd":364.4000000001397,"connectStart":364.4000000001397,"secureConnectionStart":364.4000000001397,"connectEnd":364.4000000001397,"requestStart":442.9000000001397,"responseStart":473.9000000001397,"firstInterimResponseStart":0,"responseEnd":502.30000000004657,"transferSize":15019,"encodedBodySize":14719,"decodedBodySize":14719,"responseStatus":200,"serverTiming":[]},{"name":"https://passport.gds.org.cn/css/common.css","entryType":"resource","startTime":364.5,"duration":184.20000000018626,"initiatorType":"link","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":364.5,"domainLookupStart":414.70000000018626,"domainLookupEnd":414.70000000018626,"connectStart":414.70000000018626,"secureConnectionStart":440.10000000009313,"connectEnd":467.70000000018626,"requestStart":467.70000000018626,"responseStart":498.9000000001397,"firstInterimResponseStart":0,"responseEnd":548.7000000001863,"transferSize":11893,"encodedBodySize":11593,"decodedBodySize":11593,"responseStatus":200,"serverTiming":[]},{"name":"https://passport.gds.org.cn/css/login.css?v=1.0.0","entryType":"resource","startTime":364.70000000018626,"duration":172.0999999998603,"initiatorType":"link","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":364.70000000018626,"domainLookupStart":415.30000000004657,"domainLookupEnd":415.30000000004657,"connectStart":415.30000000004657,"secureConnectionStart":444.20000000018626,"connectEnd":474.80000000004657,"requestStart":475.10000000009313,"responseStart":507.20000000018626,"firstInterimResponseStart":0,"responseEnd":536.8000000000466,"transferSize":4138,"encodedBodySize":3838,"decodedBodySize":3838,"responseStatus":200,"serverTiming":[]},{"name":"https://passport.gds.org.cn/js/jquery-3.3.1.min.js","entryType":"resource","startTime":364.80000000004657,"duration":340.60000000009313,"initiatorType":"script","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":364.80000000004657,"domainLookupStart":420.80000000004657,"domainLookupEnd":420.80000000004657,"connectStart":420.80000000004657,"secureConnectionStart":444.9000000001397,"connectEnd":475,"requestStart":475.10000000009313,"responseStart":506.60000000009313,"firstInterimResponseStart":0,"responseEnd":705.4000000001397,"transferSize":87230,"encodedBodySize":86930,"decodedBodySize":86930,"responseStatus":200,"serverTiming":[]},{"name":"https://passport.gds.org.cn/js/iconfont.js","entryType":"resource","startTime":365,"duration":233.5,"initiatorType":"script","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":365,"domainLookupStart":423.30000000004657,"domainLookupEnd":423.30000000004657,"connectStart":423.30000000004657,"secureConnectionStart":452,"connectEnd":484.70000000018626,"requestStart":484.9000000001397,"responseStart":514.8000000000466,"firstInterimResponseStart":0,"responseEnd":598.5,"transferSize":21432,"encodedBodySize":21132,"decodedBodySize":21132,"responseStatus":200,"serverTiming":[]},{"name":"https://passport.gds.org.cn/lib/bootstrap/dist/js/bootstrap.js","entryType":"resource","startTime":365.20000000018626,"duration":330.29999999981374,"initiatorType":"script","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":365.20000000018626,"domainLookupStart":365.20000000018626,"domainLookupEnd":365.20000000018626,"connectStart":365.20000000018626,"secureConnectionStart":365.20000000018626,"connectEnd":365.20000000018626,"requestStart":502.5,"responseStart":537.9000000001397,"firstInterimResponseStart":0,"responseEnd":695.5,"transferSize":135379,"encodedBodySize":135079,"decodedBodySize":135079,"responseStatus":200,"serverTiming":[]},{"name":"https://g.alicdn.com/AWSC/AWSC/awsc.js","entryType":"resource","startTime":365.4000000001397,"duration":99.0999999998603,"initiatorType":"script","deliveryType":"","nextHopProtocol":"h2","renderBlockingStatus":"blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":365.4000000001397,"domainLookupStart":436.10000000009313,"domainLookupEnd":436.10000000009313,"connectStart":436.10000000009313,"secureConnectionStart":441,"connectEnd":451.80000000004657,"requestStart":452.4000000001397,"responseStart":463.60000000009313,"firstInterimResponseStart":0,"responseEnd":464.5,"transferSize":3755,"encodedBodySize":3455,"decodedBodySize":8776,"responseStatus":0,"serverTiming":[]},{"name":"https://passport.gds.org.cn/imgs/gs1_logo.png","entryType":"resource","startTime":475,"duration":99.9000000001397,"initiatorType":"img","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"non-blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":475,"domainLookupStart":475,"domainLookupEnd":475,"connectStart":475,"secureConnectionStart":475,"connectEnd":475,"requestStart":537.8000000000466,"responseStart":573.1000000000931,"firstInterimResponseStart":0,"responseEnd":574.9000000001397,"transferSize":4566,"encodedBodySize":4266,"decodedBodySize":4266,"responseStatus":200,"serverTiming":[]},{"name":"https://passport.gds.org.cn/js/swiper.min.js","entryType":"resource","startTime":475.30000000004657,"duration":273.69999999995343,"initiatorType":"script","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"non-blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":475.30000000004657,"domainLookupStart":475.30000000004657,"domainLookupEnd":475.30000000004657,"connectStart":475.30000000004657,"secureConnectionStart":475.30000000004657,"connectEnd":475.30000000004657,"requestStart":586,"responseStart":617.6000000000931,"firstInterimResponseStart":0,"responseEnd":749,"transferSize":67085,"encodedBodySize":66785,"decodedBodySize":66785,"responseStatus":200,"serverTiming":[]},{"name":"https://passport.gds.org.cn/js/jquery.validate.min.js","entryType":"resource","startTime":475.4000000001397,"duration":218.19999999995343,"initiatorType":"script","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"non-blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":475.4000000001397,"domainLookupStart":475.4000000001397,"domainLookupEnd":475.4000000001397,"connectStart":475.4000000001397,"secureConnectionStart":475.4000000001397,"connectEnd":475.4000000001397,"requestStart":600.1000000000931,"responseStart":636.2000000001863,"firstInterimResponseStart":0,"responseEnd":693.6000000000931,"transferSize":24743,"encodedBodySize":24443,"decodedBodySize":24443,"responseStatus":200,"serverTiming":[]},{"name":"https://passport.gds.org.cn/js/util.js?ver=1.1","entryType":"resource","startTime":475.5,"duration":261.20000000018626,"initiatorType":"script","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"non-blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":475.5,"domainLookupStart":475.5,"domainLookupEnd":475.5,"connectStart":475.5,"secureConnectionStart":475.5,"connectEnd":475.5,"requestStart":701.9000000001397,"responseStart":735.9000000001397,"firstInterimResponseStart":0,"responseEnd":736.7000000001863,"transferSize":3666,"encodedBodySize":3366,"decodedBodySize":3366,"responseStatus":200,"serverTiming":[]},{"name":"https://passport.gds.org.cn/css/base.css","entryType":"resource","startTime":537.4000000001397,"duration":47.699999999953434,"initiatorType":"css","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":537.4000000001397,"domainLookupStart":537.4000000001397,"domainLookupEnd":537.4000000001397,"connectStart":537.4000000001397,"secureConnectionStart":537.4000000001397,"connectEnd":537.4000000001397,"requestStart":548.9000000001397,"responseStart":581.1000000000931,"firstInterimResponseStart":0,"responseEnd":585.1000000000931,"transferSize":4430,"encodedBodySize":4130,"decodedBodySize":4130,"responseStatus":200,"serverTiming":[]},{"name":"https://passport.gds.org.cn/css/normalize.min.css","entryType":"resource","startTime":549.2000000001863,"duration":61.199999999953434,"initiatorType":"css","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":549.2000000001863,"domainLookupStart":549.2000000001863,"domainLookupEnd":549.2000000001863,"connectStart":549.2000000001863,"secureConnectionStart":549.2000000001863,"connectEnd":549.2000000001863,"requestStart":575.3000000000466,"responseStart":609.8000000000466,"firstInterimResponseStart":0,"responseEnd":610.4000000001397,"transferSize":2701,"encodedBodySize":2401,"decodedBodySize":2401,"responseStatus":200,"serverTiming":[]},{"name":"https://g.alicdn.com/AWSC/et/1.70.8/et_f.js","entryType":"resource","startTime":720.4000000001397,"duration":26.899999999906868,"initiatorType":"script","deliveryType":"","nextHopProtocol":"h2","renderBlockingStatus":"non-blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":720.4000000001397,"domainLookupStart":720.4000000001397,"domainLookupEnd":720.4000000001397,"connectStart":720.4000000001397,"secureConnectionStart":720.4000000001397,"connectEnd":720.4000000001397,"requestStart":722.6000000000931,"responseStart":736.9000000001397,"firstInterimResponseStart":0,"responseEnd":747.3000000000466,"transferSize":73493,"encodedBodySize":73193,"decodedBodySize":211928,"responseStatus":0,"serverTiming":[]},{"name":"https://passport.gds.org.cn/imgs/banner_bg.jpg","entryType":"resource","startTime":724.8000000000466,"duration":119.60000000009313,"initiatorType":"css","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"non-blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":724.8000000000466,"domainLookupStart":724.8000000000466,"domainLookupEnd":724.8000000000466,"connectStart":724.8000000000466,"secureConnectionStart":724.8000000000466,"connectEnd":724.8000000000466,"requestStart":726.5,"responseStart":757.9000000001397,"firstInterimResponseStart":0,"responseEnd":844.4000000001397,"transferSize":44525,"encodedBodySize":44225,"decodedBodySize":44225,"responseStatus":200,"serverTiming":[]},{"name":"https://g.alicdn.com/AWSC/fireyejs/1.227.0/fireyejs.js","entryType":"resource","startTime":802.1000000000931,"duration":27.399999999906868,"initiatorType":"script","deliveryType":"","nextHopProtocol":"h2","renderBlockingStatus":"non-blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":802.1000000000931,"domainLookupStart":802.1000000000931,"domainLookupEnd":802.1000000000931,"connectStart":802.1000000000931,"secureConnectionStart":802.1000000000931,"connectEnd":802.1000000000931,"requestStart":804.6000000000931,"responseStart":813.2000000001863,"firstInterimResponseStart":0,"responseEnd":829.5,"transferSize":125845,"encodedBodySize":125545,"decodedBodySize":260174,"responseStatus":0,"serverTiming":[]},{"name":"https://g.alicdn.com/AWSC/nc/1.97.0/nc.js","entryType":"resource","startTime":802.6000000000931,"duration":27.699999999953434,"initiatorType":"script","deliveryType":"","nextHopProtocol":"h2","renderBlockingStatus":"non-blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":802.6000000000931,"domainLookupStart":802.6000000000931,"domainLookupEnd":802.6000000000931,"connectStart":802.6000000000931,"secureConnectionStart":802.6000000000931,"connectEnd":802.6000000000931,"requestStart":804.6000000000931,"responseStart":826.8000000000466,"firstInterimResponseStart":0,"responseEnd":830.3000000000466,"transferSize":22230,"encodedBodySize":21930,"decodedBodySize":72240,"responseStatus":0,"serverTiming":[]},{"name":"https://byafh5.tdum.alibaba.com/dss.js","entryType":"resource","startTime":981.2000000001863,"duration":0,"initiatorType":"script","deliveryType":"","nextHopProtocol":"","renderBlockingStatus":"non-blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":981.2000000001863,"domainLookupStart":0,"domainLookupEnd":0,"connectStart":0,"secureConnectionStart":0,"connectEnd":0,"requestStart":0,"responseStart":0,"firstInterimResponseStart":0,"responseEnd":981.2000000001863,"transferSize":0,"encodedBodySize":0,"decodedBodySize":0,"responseStatus":0,"serverTiming":[]},{"name":"https://ynuf.aliapp.org/w/wu.json","entryType":"resource","startTime":1000.9000000001397,"duration":127,"initiatorType":"script","deliveryType":"","nextHopProtocol":"","renderBlockingStatus":"non-blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":1000.9000000001397,"domainLookupStart":0,"domainLookupEnd":0,"connectStart":0,"secureConnectionStart":0,"connectEnd":0,"requestStart":0,"responseStart":0,"firstInterimResponseStart":0,"responseEnd":1127.9000000001397,"transferSize":0,"encodedBodySize":0,"decodedBodySize":0,"responseStatus":0,"serverTiming":[]},{"name":"https://cf.aliyun.com/nocaptcha/initialize.jsonp?a=FFFF0N0000000000ACD7&t=FFFF0N0000000000ACD7%3Anc_login%3A1708262910526%3A0.2319405568012629&scene=nc_login&lang=cn&v=v1.3.21&href=https%3A%2F%2Fpassport.gds.org.cn%2FAccount%2FLogin&comm={}&callback=initializeJsonp_0254697317808499","entryType":"resource","startTime":1034.4000000001397,"duration":134.80000000004657,"initiatorType":"script","deliveryType":"","nextHopProtocol":"","renderBlockingStatus":"non-blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":1034.4000000001397,"domainLookupStart":0,"domainLookupEnd":0,"connectStart":0,"secureConnectionStart":0,"connectEnd":0,"requestStart":0,"responseStart":0,"firstInterimResponseStart":0,"responseEnd":1169.2000000001863,"transferSize":0,"encodedBodySize":0,"decodedBodySize":0,"responseStatus":0,"serverTiming":[]},{"name":"https://at.alicdn.com/t/font_1465353706_4784257.woff","entryType":"resource","startTime":1041,"duration":71.80000000004657,"initiatorType":"css","deliveryType":"","nextHopProtocol":"h2","renderBlockingStatus":"non-blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":1041,"domainLookupStart":1067.5,"domainLookupEnd":1067.5,"connectStart":1067.5,"secureConnectionStart":1079.9000000001397,"connectEnd":1097.8000000000466,"requestStart":1098.1000000000931,"responseStart":1110.5,"firstInterimResponseStart":0,"responseEnd":1112.8000000000466,"transferSize":5516,"encodedBodySize":5216,"decodedBodySize":5216,"responseStatus":200,"serverTiming":[]},{"name":"https://passport.gds.org.cn/favicon.ico","entryType":"resource","startTime":1172.7000000001863,"duration":35.5,"initiatorType":"other","deliveryType":"","nextHopProtocol":"http/1.1","renderBlockingStatus":"non-blocking","workerStart":0,"redirectStart":0,"redirectEnd":0,"fetchStart":1172.7000000001863,"domainLookupStart":1172.7000000001863,"domainLookupEnd":1172.7000000001863,"connectStart":1172.7000000001863,"secureConnectionStart":1172.7000000001863,"connectEnd":1172.7000000001863,"requestStart":1176.9000000001397,"responseStart":1207.3000000000466,"firstInterimResponseStart":0,"responseEnd":1208.2000000001863,"transferSize":310,"encodedBodySize":10,"decodedBodySize":10,"responseStatus":200,"serverTiming":[]}],
    'timeOrigin':1708262909502
};

