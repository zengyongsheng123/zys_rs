// GPUShaderStage对象
bodaEnv.memory.globlProtoObj["GPUShaderStage"] = {};
Object.defineProperty(bodaEnv.memory.globlProtoObj["GPUShaderStage"], Symbol.toStringTag, {
  value: 'GPUShaderStage',
  configurable: true,
  writable: false,
  enumerable: false
}, 'bobo');
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["GPUShaderStage"], "VERTEX", {
  configurable: false,
  enumerable: true,
  writable: false,
  value: 1
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["GPUShaderStage"], "FRAGMENT", {
  configurable: false,
  enumerable: true,
  writable: false,
  value: 2
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["GPUShaderStage"], "COMPUTE", {
  configurable: false,
  enumerable: true,
  writable: false,
  value: 4
});