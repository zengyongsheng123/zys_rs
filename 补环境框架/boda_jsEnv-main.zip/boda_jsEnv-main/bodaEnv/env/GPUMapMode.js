// GPUMapMode对象
bodaEnv.memory.globlProtoObj["GPUMapMode"] = {};
Object.defineProperty(bodaEnv.memory.globlProtoObj["GPUMapMode"], Symbol.toStringTag, {
  value: 'GPUMapMode',
  configurable: true,
  writable: false,
  enumerable: false
}, 'bobo');
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["GPUMapMode"], "READ", {
  configurable: false,
  enumerable: true,
  writable: false,
  value: 1
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["GPUMapMode"], "WRITE", {
  configurable: false,
  enumerable: true,
  writable: false,
  value: 2
});