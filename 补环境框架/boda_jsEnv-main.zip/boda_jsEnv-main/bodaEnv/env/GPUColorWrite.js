// GPUColorWrite对象
bodaEnv.memory.globlProtoObj["GPUColorWrite"] = {};
Object.defineProperty(bodaEnv.memory.globlProtoObj["GPUColorWrite"], Symbol.toStringTag, {
  value: 'GPUColorWrite',
  configurable: true,
  writable: false,
  enumerable: false
}, 'bobo');
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["GPUColorWrite"], "RED", {
  configurable: false,
  enumerable: true,
  writable: false,
  value: 1
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["GPUColorWrite"], "GREEN", {
  configurable: false,
  enumerable: true,
  writable: false,
  value: 2
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["GPUColorWrite"], "BLUE", {
  configurable: false,
  enumerable: true,
  writable: false,
  value: 4
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["GPUColorWrite"], "ALPHA", {
  configurable: false,
  enumerable: true,
  writable: false,
  value: 8
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["GPUColorWrite"], "ALL", {
  configurable: false,
  enumerable: true,
  writable: false,
  value: 15
});