// CSS对象
bodaEnv.memory.globlProtoObj["CSS"] = {};
Object.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], Symbol.toStringTag, {
  value: 'CSS',
  configurable: true,
  writable: false,
  enumerable: false
}, 'bobo');
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "Hz", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    Hz() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "Hz", arguments);
    }
  }.Hz
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "Q", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    Q() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "Q", arguments);
    }
  }.Q
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "ch", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    ch() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "ch", arguments);
    }
  }.ch
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "cm", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    cm() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "cm", arguments);
    }
  }.cm
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "cqb", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    cqb() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "cqb", arguments);
    }
  }.cqb
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "cqh", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    cqh() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "cqh", arguments);
    }
  }.cqh
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "cqi", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    cqi() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "cqi", arguments);
    }
  }.cqi
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "cqmax", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    cqmax() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "cqmax", arguments);
    }
  }.cqmax
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "cqmin", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    cqmin() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "cqmin", arguments);
    }
  }.cqmin
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "cqw", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    cqw() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "cqw", arguments);
    }
  }.cqw
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "deg", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    deg() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "deg", arguments);
    }
  }.deg
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "dpcm", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    dpcm() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "dpcm", arguments);
    }
  }.dpcm
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "dpi", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    dpi() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "dpi", arguments);
    }
  }.dpi
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "dppx", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    dppx() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "dppx", arguments);
    }
  }.dppx
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "em", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    em() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "em", arguments);
    }
  }.em
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "escape", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    escape() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "escape", arguments);
    }
  }.escape
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "ex", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    ex() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "ex", arguments);
    }
  }.ex
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "fr", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    fr() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "fr", arguments);
    }
  }.fr
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "grad", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    grad() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "grad", arguments);
    }
  }.grad
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "in", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    boin() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "boin", arguments);
    }
  }.boin
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "kHz", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    kHz() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "kHz", arguments);
    }
  }.kHz
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "mm", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    mm() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "mm", arguments);
    }
  }.mm
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "ms", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    ms() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "ms", arguments);
    }
  }.ms
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "number", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    number() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "number", arguments);
    }
  }.number
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "pc", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    pc() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "pc", arguments);
    }
  }.pc
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "percent", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    percent() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "percent", arguments);
    }
  }.percent
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "pt", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    pt() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "pt", arguments);
    }
  }.pt
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "px", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    px() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "px", arguments);
    }
  }.px
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "rad", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    rad() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "rad", arguments);
    }
  }.rad
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "registerProperty", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    registerProperty() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "registerProperty", arguments);
    }
  }.registerProperty
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "rem", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    rem() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "rem", arguments);
    }
  }.rem
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "s", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    s() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "s", arguments);
    }
  }.s
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "supports", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    supports() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "supports", arguments);
    }
  }.supports
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "turn", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    turn() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "turn", arguments);
    }
  }.turn
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "vh", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    vh() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "vh", arguments);
    }
  }.vh
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "vmax", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    vmax() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "vmax", arguments);
    }
  }.vmax
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "vmin", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    vmin() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "vmin", arguments);
    }
  }.vmin
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "vw", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    vw() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "vw", arguments);
    }
  }.vw
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "highlights", {
  configurable: true,
  enumerable: true,
  get: {
    highlights() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "highlights_get", arguments);
    }
  }.highlights,
  set: undefined
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "dvb", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    dvb() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "dvb", arguments);
    }
  }.dvb
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "dvh", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    dvh() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "dvh", arguments);
    }
  }.dvh
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "dvi", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    dvi() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "dvi", arguments);
    }
  }.dvi
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "dvmax", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    dvmax() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "dvmax", arguments);
    }
  }.dvmax
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "dvmin", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    dvmin() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "dvmin", arguments);
    }
  }.dvmin
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "dvw", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    dvw() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "dvw", arguments);
    }
  }.dvw
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "lvb", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    lvb() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "lvb", arguments);
    }
  }.lvb
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "lvh", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    lvh() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "lvh", arguments);
    }
  }.lvh
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "lvi", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    lvi() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "lvi", arguments);
    }
  }.lvi
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "lvmax", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    lvmax() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "lvmax", arguments);
    }
  }.lvmax
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "lvmin", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    lvmin() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "lvmin", arguments);
    }
  }.lvmin
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "lvw", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    lvw() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "lvw", arguments);
    }
  }.lvw
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "svb", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    svb() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "svb", arguments);
    }
  }.svb
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "svh", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    svh() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "svh", arguments);
    }
  }.svh
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "svi", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    svi() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "svi", arguments);
    }
  }.svi
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "svmax", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    svmax() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "svmax", arguments);
    }
  }.svmax
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "svmin", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    svmin() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "svmin", arguments);
    }
  }.svmin
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "svw", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    svw() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "svw", arguments);
    }
  }.svw
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "vb", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    vb() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "vb", arguments);
    }
  }.vb
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "vi", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    vi() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "vi", arguments);
    }
  }.vi
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["CSS"], "paintWorklet", {
  configurable: true,
  enumerable: true,
  get: {
    paintWorklet() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["CSS"], "CSS", "paintWorklet_get", arguments);
    }
  }.paintWorklet,
  set: undefined
});