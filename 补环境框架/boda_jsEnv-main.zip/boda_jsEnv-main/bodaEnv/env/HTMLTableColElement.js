// HTMLTableColElement对象

bodaEnv.memory.globlProtoObj["HTMLTableColElement"] = function HTMLTableColElement() {
  let arg = arguments[0];
  if (arg != 'bobo') {
    bodaEnv.toolsFunc.console_copy('HTMLTableColElement 实例化对象 --->', bodaEnv.toolsFunc.stringify_bo(arguments, function (k, v) {
      if (v == window) {
        return 'window';
      } else {
        return v;
      }
    }));
  }
  ;
};
bodaEnv.toolsFunc.safeProto(bodaEnv.memory.globlProtoObj["HTMLTableColElement"], "HTMLTableColElement");
bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype.__proto__ = bodaEnv.memory.globlProtoObj["HTMLElement"].prototype;
bodaEnv.memory.globlProtoObj["HTMLTableColElement"].__proto__ = bodaEnv.memory.globlProtoObj["HTMLElement"];
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "span", {
  configurable: true,
  enumerable: true,
  get: {
    span() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "HTMLTableColElement", "span_get", arguments);
    }
  }.span,
  set: {
    span() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "HTMLTableColElement", "span_set", arguments);
    }
  }.span
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "align", {
  configurable: true,
  enumerable: true,
  get: {
    align() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "HTMLTableColElement", "align_get", arguments);
    }
  }.align,
  set: {
    align() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "HTMLTableColElement", "align_set", arguments);
    }
  }.align
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "ch", {
  configurable: true,
  enumerable: true,
  get: {
    ch() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "HTMLTableColElement", "ch_get", arguments);
    }
  }.ch,
  set: {
    ch() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "HTMLTableColElement", "ch_set", arguments);
    }
  }.ch
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "chOff", {
  configurable: true,
  enumerable: true,
  get: {
    chOff() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "HTMLTableColElement", "chOff_get", arguments);
    }
  }.chOff,
  set: {
    chOff() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "HTMLTableColElement", "chOff_set", arguments);
    }
  }.chOff
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "vAlign", {
  configurable: true,
  enumerable: true,
  get: {
    vAlign() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "HTMLTableColElement", "vAlign_get", arguments);
    }
  }.vAlign,
  set: {
    vAlign() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "HTMLTableColElement", "vAlign_set", arguments);
    }
  }.vAlign
});
bodaEnv.toolsFunc.defineProperty(bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "width", {
  configurable: true,
  enumerable: true,
  get: {
    width() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "HTMLTableColElement", "width_get", arguments);
    }
  }.width,
  set: {
    width() {
      return bodaEnv.toolsFunc.dispatch(this, bodaEnv.memory.globlProtoObj["HTMLTableColElement"].prototype, "HTMLTableColElement", "width_set", arguments);
    }
  }.width
});