import json
import subprocess
import os
from curl_cffi import requests
# import requests
import time
import hashlib
import random
import urllib.parse

# requests = requests.session()


def get_sha(text):
    sha = hashlib.sha256()
    sha.update(text.encode())
    return sha.hexdigest()


def get_clean_h5st(params_dict, actual_timestamp):
    """获取纯净的 h5st"""
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        js_file_path = os.path.join(current_dir, '111.js')

        with open(js_file_path, 'r', encoding='utf-8') as f:
            js_code = f.read()

        silent_script = f"""
console.log = function() {{}};
console.error = function() {{}};
console.warn = function() {{}};
console.info = function() {{}};

{js_code}

try {{
    const params = {json.dumps(params_dict, ensure_ascii=False)};
    // 使用实际的时间戳
    params.t = "{actual_timestamp}";
    const result = get_h5st(params);
    if (result && typeof result === 'string') {{
        process.stdout.write(result);
    }} else {{
        process.exit(1);
    }}
}} catch (error) {{
    process.exit(1);
}}
"""

        temp_js_path = os.path.join(current_dir, f'temp_silent_{int(time.time() * 1000)}.js')
        with open(temp_js_path, 'w', encoding='utf-8') as f:
            f.write(silent_script)

        result = subprocess.run(
            ['node', temp_js_path],
            capture_output=True,
            text=True,
            timeout=30,
            cwd=current_dir
        )

        try:
            os.remove(temp_js_path)
        except:
            pass

        if result.returncode == 0:
            h5st = result.stdout.strip()
            if h5st and 500 < len(h5st) < 1000 and h5st.count(';') >= 5:
                return h5st
        return None

    except Exception as e:
        print(f"❌ h5st 生成失败: {e}")
        return None


def generate_random_pvid():
    """生成随机 pvid"""
    return ''.join(random.choices('abcdef0123456789', k=32))


def generate_random_area():
    """生成随机地区编码"""
    areas = [
        "1_72_55653_0", "1_72_0_0", "2_2818_51976_0", "2_2818_0_0",
        "3_770_34704_0", "3_770_0_0", "4_891_899_0", "4_891_0_0",
        "15_1212_0_0", "22_1930_0_0", "12_904_0_0", "5_109_0_0",
        "19_1601_0_0", "25_3118_0_0", "30_51036_0_0", "17_1381_0_0",
        "31_2917_0_0", "13_1136_0_0", "18_1465_0_0", "11_842_0_0",
        "20_1722_0_0", "21_1827_0_0", "28_3517_0_0", "32_3223_0_0",
        "24_2898_0_0", "6_280_0_0", "10_796_0_0", "7_368_0_0",
        "8_526_0_0", "9_702_0_0", "14_1253_0_0", "16_1343_0_0",
        "23_2756_0_0", "26_3342_0_0", "27_3443_0_0",
    ]
    return random.choice(areas)


def get_s_value_by_page(page):
    """
    根据已知的 s 值模式重新计算
    已知数据点：
    - 第1页: s=1
    - 第3页: s=47
    - 第5页: s=92
    - 第7页: s=137

    重新分析：
    第1页到第3页：间隔2页，s增加46 (47-1=46)，平均每页增加23
    第3页到第5页：间隔2页，s增加45 (92-47=45)，平均每页增加22.5
    第5页到第7页：间隔2页，s增加45 (137-92=45)，平均每页增加22.5

    看起来模式在变化，让我们尝试更精确的计算
    """

    # 基于已知数据点的精确映射
    s_mapping = {
        1: 1,  # 已知
        2: 24,  # 推算 (1 + 23)
        3: 47,  # 已知
        4: 69,  # 推算 (47 + 22)
        5: 92,  # 已知
        6: 114,  # 推算 (92 + 22)
        7: 137,  # 已知
        8: 159,  # 推算 (137 + 22)
        9: 182,  # 推算 (159 + 23)
        10: 204,  # 推算 (182 + 22)
        11: 227,  # 推算 (204 + 23)
        12: 249,  # 推算 (227 + 22)
        13: 272,  # 推算 (249 + 23)
        14: 294,  # 推算 (272 + 22)
        15: 317,  # 推算 (294 + 23)
    }

    # 如果在映射表中，返回对应值
    if page in s_mapping:
        return s_mapping[page]
    else:
        # 超出范围的页面使用交替增量
        # 奇数页增加23，偶数页增加22
        base_s = 1
        for i in range(2, page + 1):
            if i % 2 == 0:  # 偶数页
                base_s += 22
            else:  # 奇数页
                base_s += 23
        return base_s


def get_random_delay(base=3):
    """生成随机延迟"""
    return base + random.uniform(1, 4)


def search_jd_single(keyword="手机", page=1, retry_count=0):
    """单次搜索请求"""

    # 延迟处理
    if retry_count > 0:
        delay = get_random_delay(3)
        print(f"🔄 第 {retry_count + 1} 次重试，等待 {delay:.1f} 秒...")
        time.sleep(delay)
    else:
        delay = get_random_delay()
        print(f"⏳ 随机延迟 {delay:.1f} 秒...")
        time.sleep(delay)

    # 生成参数
    random_pvid = generate_random_pvid()
    random_area = generate_random_area()
    s_value = get_s_value_by_page(page)

    # 构建请求体
    pre_body = {
        "enc": "utf-8",
        "pvid": random_pvid,
        "area": random_area,
        "page": page,
        "new_interval": True,
        "s": s_value
    }

    pre_body_str = json.dumps(pre_body, ensure_ascii=False, separators=(',', ':'))
    body = get_sha(pre_body_str)

    print(f'\n🔍 搜索: {keyword} | 页码: {page}')
    print('pvid:', random_pvid)
    print('area:', random_area)
    print('s 值:', s_value)
    print('body:', pre_body_str)  # 打印完整body用于调试
    time_stamp = str(int(time.time() * 1000))

    # 构建预参数时使用相同的时间戳
    pre_params = {
        'appid': 'search-pc-java',
        'body': body,
        'functionId': "pc_search_searchWare",
        'client': 'pc',
        'clientVersion': '1.0.0',
        't': time_stamp  # 使用相同的时间戳
    }

    print("🔄 生成 h5st...")
    h5st = get_clean_h5st(pre_params, time_stamp)  # 传入实际时间戳

    if not h5st:
        print("❌ h5st 生成失败")
        return None

    print(f'✅ h5st 生成成功, 长度: {len(h5st)}')

    # 构建请求
    encoded_keyword = urllib.parse.quote(keyword)

    params = {
        "appid": "search-pc-java",
        "t": time_stamp,
        "client": "pc",
        "clientVersion": "1.0.0",
        "cthr": "1",
        "uuid": "17609694100021900363389",
        "loginType": "3",
        "keyword": keyword,
        "functionId": "pc_search_searchWare",
        "body": pre_body_str,
        "x-api-eid-token": "jdd03ZPWPRZBRRWBD5IDHA5MKXGI2SEJIF2CXWEK22CHK4OKB46KHVQK6FOW33ZDUJJRXY2O5R65EYOTB6W42IVJPM24HUEAAAAM2BO3L32QAAAAACPGC5X4CLY52PQX",
        "h5st": h5st
    }

    headers = {
        "accept": "application/json, text/plain, */*",
        "accept-language": "zh,zh-CN;q=0.9",
        "cache-control": "no-cache",
        "origin": "https://search.jd.com",
        "pragma": "no-cache",
        "priority": "u=1, i",
        "referer": f"https://search.jd.com/Search?keyword={encoded_keyword}&enc=utf-8",
        "sec-ch-ua": "\"Google Chrome\";v=\"141\", \"Not?A_Brand\";v=\"8\", \"Chromium\";v=\"141\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
        "x-referer-page": "https://search.jd.com/Search",
        "x-rp-client": "h5_1.0.0"
    }

    cookies = {
        "__jdv": "76161171|cn.bing.com|-|referral|-|1760969410003",
        "__jdu": "17609694100021900363389",
        "shshshfpa": "285eb675-7717-320f-c379-1f1cf422f10e-1760969440",
        "shshshfpx": "285eb675-7717-320f-c379-1f1cf422f10e-1760969440",
        "jcap_dvzw_fp": "_CbBNjdqoz_uGfq_bDDcMr5mhvYJ0EviNQIyVNXIIznvyB46zsrve2MkgEIMAOGwGkX8OSxzT91b-MMVSrtMRuaxq8U=",
        "TrackID": "1k0PZgYIyHL-BBUn-1WFVLjze-saZafirRtrkTC1HSZiNoMh4Kv-WD95fbeGF4aeNv5_kCS9DbZm9SAQLNeMgnkXtSozMTHytjSVwn3Hy9XY",
        "pinId": "Z_RulOG-J27d71tPa3l1iw",
        "pin": "jd_DpKnwcKTUZZG",
        "unick": "t0wd2u0z6pw1vh",
        "_tp": "GSi0H9%2BqGDdfdwyFnYkXBw%3D%3D",
        "_pst": "jd_DpKnwcKTUZZG",
        "areaId": "19",
        "ipLoc-djd": "1-72-55653-0",
        "mba_muid": "17609694100021900363389",
        "mba_sid": "17611316402402138006458.2",
        "wlfstk_smdl": "nnrz1dfslxkxie9fty89umddgvm31hpo",
        "3AB9D23F7A4B3CSS": "jdd03ZPWPRZBRRWBD5IDHA5MKXGI2SEJIF2CXWEK22CHK4OKB46KHVQK6FOW33ZDUJJRXY2O5R65EYOTB6W42IVJPM24HUEAAAAM2BOR6SWYAAAAACNLCLKQEBLSRBUX",
        "_gia_d": "1",
        "thor": "251ECB82F51D8C8D4E3D1428DB84C3209944C3190610545ADFD85FB4E0138CA73341C89CECD3784A4C92A289058064AC6F24321372019CBBBB1359E2FF7C345C10D9B9E1C18D8A32722E78F778EAA502ED6D62EF8B772D4978FD89B97F554B5E06D06991C2296982EB15EA15858914E17F989ACAF3B47A196EE1CBE2C1C97E6A68166EA160CC7EEFB50E360009BEE3A1B55729994BF5BFFF4213F852DBB629CF",
        "light_key": "AASBKE7rOxgWQziEhC_QY6ya5oQuxk-6UqRndM1i7qqtgpHohbasOABOu75xpakBAjW3TLTn",
        "ceshi3.com": "000",
        "__jda": "143920055.17609694100021900363389.1760969410.1761127102.1761131475.3",
        "__jdc": "143920055",
        "__jdb": "143920055.17.17609694100021900363389|3.1761131475",
        "flash": "3_GQqyDtNDzUTLiYbiJrVyY9kSncnJSNa-zff_SUPUCOiL6uxMSY0uMrmQxa4bEhtIAQqPXS6uGn02la9EpIozP_NZJWWgXE1qwhH24TMcmUhbYChytjpWo88NIXFRBay-JbRJKZtWiFAy8So3wNC1YXsHACROO8VQ6jQ9eoi6EX-K6pG37WQQ",
        "cn": "0",
        "shshshfpb": "BApXWoc2sCP9AqBhlhVDcu3GwdmtP5EDUBiLXk29p9xJ1PdZfQqLGuRT8jwDOBrxJVDx6IKnnnaeqeQ",
        "3AB9D23F7A4B3C9B": "ZPWPRZBRRWBD5IDHA5MKXGI2SEJIF2CXWEK22CHK4OKB46KHVQK6FOW33ZDUJJRXY2O5R65EYOTB6W42IVJPM24HUE",
        "sdtoken": "AAbEsBpEIOVjqTAKCQtvQu17ye-NMJCvb8VPS-28BDnUph09XxMoMP0DOrCyK-6dm4Gk-WF55kPTIRaiLNKb7mrmQh8e9tkTgSz-YNxc0wpy0SQqk09kZ23ojmMXWp_schs2k_eMjhZ_GFkGo3nGvdYLZSchEulsmuljH_re7y26Hl5HT0t9b1RTzGqpcEo5Wa8Kee5IMg"
    }

    url = "https://api.m.jd.com/api"

    print("🚀 发送请求...")
    try:
        response = requests.get(
            url,
            headers=headers,
            cookies=cookies,
            params=params,
            impersonate="chrome110"
        )
        print("📡 响应状态码:", response.status_code)

        if response.status_code == 200:
            data = response.json()
            print(data)
            print("🎉 请求成功！")

            # 解析商品数据
            if 'wareInfo' in data and data['wareInfo']:
                print(f"📦 找到商品数量: {len(data['wareInfo'])}")
                for i, ware in enumerate(data['wareInfo'][:3], 1):
                    name = ware.get('wname', '未知商品')[:30]
                    price = ware.get('price', '未知价格')
                    print(f"  {i}. {name} - ¥{price}")
            else:
                print("📊 响应数据（无商品信息）")
            return data

        elif response.status_code == 403:
            print("🚫 请求被拒绝 (403)")

            if retry_count < 2:
                print(f"🔄 准备第 {retry_count + 1} 次重试...")
                return search_jd_single(keyword, page, retry_count + 1)
            else:
                print("❌ 重试次数已达上限，放弃请求")
                return None
        else:
            print(f"❌ 请求失败，状态码: {response.status_code}")
            return None

    except Exception as e:
        print(f"❌ 请求异常: {e}")
        return None


if __name__ == "__main__":
    keyword = "手机"

    # 记录成功和失败的页面
    success_pages = []
    failed_pages = []

    # 测试前10页
    test_pages = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    for page in test_pages:
        print(f"\n{'=' * 40}")
        print(f"=== 测试第 {page} 页 (s值: {get_s_value_by_page(page)}) ===")
        print(f"{'=' * 40}")

        result = search_jd_single(keyword, page=page)

        if result is None:
            print(f"❌ 第 {page} 页请求失败")
            failed_pages.append(page)
        else:
            print(f"✅ 第 {page} 页请求成功")
            success_pages.append(page)

        # 等待下一页
        if page < test_pages[-1]:
            next_delay = get_random_delay(random.randint(1, 3))
            print(f"\n⏳ 准备下一页，等待 {next_delay:.1f} 秒...")
            time.sleep(next_delay)

    # 输出统计结果
    print(f"\n{'=' * 50}")
    print("📊 测试结果统计:")
    print(f"✅ 成功页面: {success_pages}")
    print(f"❌ 失败页面: {failed_pages}")
    print(f"📈 成功率: {len(success_pages)}/{len(test_pages)} = {len(success_pages) / len(test_pages) * 100:.1f}%")
    print(f"{'=' * 50}")

    # 分析失败页面的s值模式
    if failed_pages:
        print("\n🔍 失败页面分析:")
        for page in failed_pages:
            current_s = get_s_value_by_page(page)
            print(f"第{page}页: s={current_s}")

        print("\n💡 建议调整s值计算:")
        for page in failed_pages:
            # 尝试不同的s值增量
            suggested_s = []
            for increment in [20, 21, 22, 23, 24]:
                suggested_s.append(1 + (page - 1) * increment)
            print(f"第{page}页可尝试: {suggested_s}")
