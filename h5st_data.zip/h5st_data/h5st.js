require("./env")
const CryptoJs = require('crypto-js')
window.PSign = new ParamsSign({
    //融合接口加签
    appId: "f06cc",
    //online
    debug: false,
    preRequest: false,
    onSign: function (res) {
    },
    // 算法请求监控回调事件 code: 200 - 请求成功，表示动态算法接口请求成功，获取到动态token 。 其他为失败
    onRequestTokenRemotely: function (res) {
    },
    onRequestToken: function (code, message) {
    }
});

function get_h5st(body, time_stamp) {
    // const body = {
    //     "page": 3,
    //     "pagesize": 25,
    //     "area": "19_1601_0_0",
    //     "source": "pc-home",
    //     "gb": 1
    // }
    // console.log(CryptoJs.SHA256(JSON.stringify(body)).toString());
    // const params = {
    //     "appid": "www-jd-com",
    //     "body": CryptoJs.SHA256(JSON.stringify(body)).toString(),
    //     "clientVersion": "1.0.0",
    //     "client": "pc",
    //     "functionId": "pc_home_feed",
    //     "t": time_stamp
    // }
    const params = {
        "appid": "search-pc-java",
        "functionId": "pc_search_searchWare",
        "client": "pc",
        "clientVersion": "1.0.0",
        "t": time_stamp,
        "body": CryptoJs.SHA256(JSON.stringify(body)).toString()
    }
    let result = window.PSign._$sdnmd(params)
    // console.log(result.h5st.length)
    return result.h5st
}

// console.log(get_h5st());