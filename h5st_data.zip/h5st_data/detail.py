import json
import random
import time
import execjs
from curl_cffi import requests


# pip install curl_cffi pyexecjs requests
class JDSearchAPI:
    def __init__(self, js_file_path="h5st.js"):
        """
        初始化JD搜索API

        Args:
            js_file_path: h5st.js文件路径
        """
        self.js_file_path = js_file_path
        self.headers = {
            "accept": "application/json, text/plain, */*",
            "accept-language": "zh,zh-CN;q=0.9",
            "cache-control": "no-cache",
            "origin": "https://search.jd.com",
            "pragma": "no-cache",
            "priority": "u=1, i",
            "sec-ch-ua": "\"Google Chrome\";v=\"141\", \"Not?A_Brand\";v=\"8\", \"Chromium\";v=\"141\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Windows\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
            "x-referer-page": "https://search.jd.com/Search",
            "x-rp-client": "h5_1.0.0"
        }
        # 替换自己的cookies
        self.cookies = {
            "shshshfpa": "08765d13-0f9b-455b-9ded-4b26e86306b0-1762437584",
            "shshshfpx": "08765d13-0f9b-455b-9ded-4b26e86306b0-1762437584",
            "__jdu": "1762437587129797165975",
            "areaId": "19",
            "mt_xid": "V2_52007VwMUVV5dUFwbQB9cBm8FGlRdX1ZSGU0pDAxvChVTXlhSDRYbTlxWYDMRU15cTlofVRhVFGcAGVJeU1ddL0spXjVXBBpVWlk%3D",
            "unpl": "V2_ZzNsbRJeSxxyCUVUe05VVzADQVpeFi0SfQ9BVUsaXQZjHxJdXlZKBHULTVR4ElkCVwMiXkNVRRZ2C0JWfClda2ALFVpDZ3MVdzhHZHsfWwZiARRZS1FDFn0OTlJ7HlgNYQciDUtfShJ0C0ZULBAOUmdQFW1FUEIc",
            "__jdv": "232945309|cn.bing.com|t_2037222536_0_0|adrealizable|a89860211f8cf1b6-p_0|1762575165479",
            "mba_muid": "1762437587129797165975",
            "mba_sid": "17627860447881895090038.1",
            "3AB9D23F7A4B3CSS": "jdd03L56UBSOLZOOA3MVSMDYCPHPWVNIZ5YMZ6Q335ZWGXT2BLQZHM2RMMRAMY7GO37XXZTQLJOXMMRGUSAAJRQ55M7YT6MAAAAM2NY6ICIQAAAAACADDIHLUUW7FG4X",
            "_gia_d": "1",
            "wlfstk_smdl": "ryjhvriqiw9h9h951c8m5lphgtdd35mv",
            "jcap_dvzw_fp": "_CbBNjdqoz_uGfq_bDDcMr5mhvYJ0EviNQIyVNXIIznvyB46zsrve2MkgEIMAOGwGkX8OSxzT91b-MMVSrtMRuaxq8U=",
            "TrackID": "1iYaKPGLEi_9pp2ApKCSCzEuuRkcGqN_zGA6PeUlr3SoOihv5CZAemX21AM8Z0mJ9AzmLF4sdK6DvErUY7nQHJR07HUQ4oA5zT9FSBS2ZTZM",
            "thor": "251ECB82F51D8C8D4E3D1428DB84C3209944C3190610545ADFD85FB4E0138CA71473943BD4BE9A96CC5C68B0D98732983CA71BD4F0DC6096D87F08DD4656F3AFAE6CE41DD06A5871F514F2AE3F8CC60042DB3A736E1BD8E1C5B46F21AC85163DB8537968DEAF72E78AAF5A7A2289BDA15F0EA2D7F33BBCC6CBDBCAA0FD8030163500518C810263075E9D5E46E4CF6D0CD4FE72F7406C52423BDCE5AD84C61F32",
            "light_key": "AASBKE7rOxgWQziEhC_QY6yaCKdoACgYkVMbUqldCY8H96hqBfpIjH_-6ybI-lgCWPw26Bdu",
            "pinId": "Z_RulOG-J27d71tPa3l1iw",
            "pin": "jd_DpKnwcKTUZZG",
            "unick": "t0wd2u0z6pw1vh",
            "ceshi3.com": "000",
            "_tp": "GSi0H9%2BqGDdfdwyFnYkXBw%3D%3D",
            "_pst": "jd_DpKnwcKTUZZG",
            "__jda": "143920055.1762437587129797165975.1762437587.1762612536.1762784948.8",
            "__jdc": "143920055",
            "flash": "3_CWsb21Ki-zezMSmzIIOmcSZ-x8qZoQP8YaUoIEjOlTLfATePZt_qaS10YzapuQqD82LBsp_2X2XNeyyvKJTyimtDnXUwLZL4K9pQCNwVezh2JRzFlBXIXtq4NWIqVs_QdM9SElq_1bCEV2f15Q04aOG1_46HT8aHTlbFiV6tqUK_ABj0OeMV",
            "shshshfpb": "BApXWldg1bf9AgPMD_dyr7y8kIlFTpbdqBiACcqtq9xJ1PdZfQqLGuRT8jwDOBrxJVASR2qjn-rL1Zg",
            "__jdb": "143920055.8.1762437587129797165975|8.1762784948",
            "cn": "0",
            "ipLoc-djd": "19-1601-50258-129167",
            "3AB9D23F7A4B3C9B": "L56UBSOLZOOA3MVSMDYCPHPWVNIZ5YMZ6Q335ZWGXT2BLQZHM2RMMRAMY7GO37XXZTQLJOXMMRGUSAAJRQ55M7YT6M",
            "sdtoken": "AAbEsBpEIOVjqTAKCQtvQu17S8Ur8ymdSWnbVGc4hPDnYfO2Pulm1ivYyq0wUVBAg6LRAv6-lyCYQUTguNz7TfMuxr8YlCJswURNsqoMseaLSvZY5-c6ZdhLBApL7TCUW7COedChoPuM_rvdRCCyKyiE7QAnmJJ19yr4-SNn"
        }
        self.url = "https://api.m.jd.com/api"

        # 加载JS文件
        with open(self.js_file_path, "r", encoding="utf-8") as f:
            self.js_code = f.read()
        self.js_context = execjs.compile(self.js_code)

    def _generate_h5st(self, body, time_stamp):
        """
        生成h5st参数

        Args:
            body: 请求体
            time_stamp: 时间戳

        Returns:
            h5st值
        """
        return self.js_context.call("get_h5st", body, str(time_stamp))

    def _generate_params(self, keyword, body, time_stamp, h5st):
        """
        生成请求参数

        Args:
            keyword: 搜索关键词
            body: 请求体
            time_stamp: 时间戳
            h5st: h5st值

        Returns:
            参数字典
        """
        return {
            "appid": "search-pc-java",
            "t": [
                str(time_stamp),
                str(time_stamp + random.randint(10, 20))
            ],
            "client": "pc",
            "clientVersion": "1.0.0",
            "cthr": "1",
            "uuid": "1762437587129797165975",
            "loginType": "3",
            "keyword": keyword,
            "functionId": "pc_search_searchWare",
            "body": json.dumps(body, separators=(',', ':')),
            "x-api-eid-token": "jdd03L56UBSOLZOOA3MVSMDYCPHPWVNIZ5YMZ6Q335ZWGXT2BLQZHM2RMMRAMY7GO37XXZTQLJOXMMRGUSAAJRQ55M7YT6MAAAAM2NY6ICIQAAAAACADDIHLUUW7FG4X",
            "h5st": h5st
        }

    def search_products(self, keyword, page=1, area="19_1601_50258_129167", pvid=None):
        """
        搜索商品

        Args:
            keyword: 搜索关键词
            page: 页码，默认为1
            area: 地区编码，默认为"19_1601_50258_129167"
            pvid: pvid参数，默认为None时会自动生成

        Returns:
            商品列表
        """
        if pvid is None:
            pvid = f"c8ee6f8f98ba4aeabf534a34348c0d{random.randint(100, 999)}"

        time_stamp = int(time.time() * 1000)

        body = {
            "enc": "utf-8",
            "pvid": pvid,
            "area": area,
            "page": page,
            "new_interval": True,
            "s": 26
        }

        h5st = self._generate_h5st(body, time_stamp)
        params = self._generate_params(keyword, body, time_stamp, h5st)

        response = requests.get(
            self.url,
            headers=self.headers,
            cookies=self.cookies,
            params=params
        )

        if response.status_code == 200:
            return response.json()
        else:
            response.raise_for_status()

    def get_product_names(self, keyword, page=1, max_retries=3):
        """
        获取商品名称列表

        Args:
            keyword: 搜索关键词
            page: 页码
            max_retries: 最大重试次数

        Returns:
            商品名称列表
        """
        for attempt in range(max_retries):
            try:
                data = self.search_products(keyword, page)
                ware_list = data.get("data", {}).get("wareList", [])
                return [ware.get("wareName") for ware in ware_list if ware.get("wareName")]
            except Exception as e:
                if attempt == max_retries - 1:
                    print(f"获取商品名称失败: {e}")
                    return []
                time.sleep(1)  # 失败后等待1秒再重试

    def batch_search(self, keyword, start_page=1, end_page=5):
        """
        批量搜索多页商品

        Args:
            keyword: 搜索关键词
            start_page: 起始页码
            end_page: 结束页码

        Returns:
            所有商品名称列表
        """
        all_products = []
        for page in range(start_page, end_page + 1):
            print(f"正在获取第{page}页...")
            product_names = self.get_product_names(keyword, page)
            all_products.extend(product_names)
            time.sleep(random.uniform(1, 2))  # 添加随机延迟避免请求过快

        return all_products


# 使用示例
if __name__ == "__main__":
    # 创建API实例
    jd_api = JDSearchAPI("h5st.js")

    # 搜索单页商品
    products = jd_api.get_product_names("美妆", page=1)
    for i, name in enumerate(products, 1):
        print(f"{i}. {name}")

    print("\n" + "=" * 50 + "\n")

    # 批量搜索多页商品
    all_products = jd_api.batch_search("美妆", start_page=1, end_page=2)
    for i, name in enumerate(all_products, 1):
        print(f"{i}. {name}")
