import json
import random
import time
import execjs
from curl_cffi import requests
headers = {
    "accept": "application/json, text/plain, */*",
    "accept-language": "zh,zh-CN;q=0.9",
    "cache-control": "no-cache",
    "origin": "https://search.jd.com",
    "pragma": "no-cache",
    "priority": "u=1, i",
    "sec-ch-ua": "\"Google Chrome\";v=\"141\", \"Not?A_Brand\";v=\"8\", \"Chromium\";v=\"141\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
    "x-referer-page": "https://search.jd.com/Search",
    "x-rp-client": "h5_1.0.0"
}
cookies = {
    "shshshfpa": "08765d13-0f9b-455b-9ded-4b26e86306b0-1762437584",
    "shshshfpx": "08765d13-0f9b-455b-9ded-4b26e86306b0-1762437584",
    "__jdu": "1762437587129797165975",
    "areaId": "19",
    "mt_xid": "V2_52007VwMUVV5dUFwbQB9cBm8FGlRdX1ZSGU0pDAxvChVTXlhSDRYbTlxWYDMRU15cTlofVRhVFGcAGVJeU1ddL0spXjVXBBpVWlk%3D",
    "unpl": "V2_ZzNsbRJeSxxyCUVUe05VVzADQVpeFi0SfQ9BVUsaXQZjHxJdXlZKBHULTVR4ElkCVwMiXkNVRRZ2C0JWfClda2ALFVpDZ3MVdzhHZHsfWwZiARRZS1FDFn0OTlJ7HlgNYQciDUtfShJ0C0ZULBAOUmdQFW1FUEIc",
    "__jdv": "232945309|cn.bing.com|t_2037222536_0_0|adrealizable|a89860211f8cf1b6-p_0|1762575165479",
    "mba_muid": "1762437587129797165975",
    "mba_sid": "17627860447881895090038.1",
    "3AB9D23F7A4B3CSS": "jdd03L56UBSOLZOOA3MVSMDYCPHPWVNIZ5YMZ6Q335ZWGXT2BLQZHM2RMMRAMY7GO37XXZTQLJOXMMRGUSAAJRQ55M7YT6MAAAAM2NY6ICIQAAAAACADDIHLUUW7FG4X",
    "_gia_d": "1",
    "wlfstk_smdl": "ryjhvriqiw9h9h951c8m5lphgtdd35mv",
    "jcap_dvzw_fp": "_CbBNjdqoz_uGfq_bDDcMr5mhvYJ0EviNQIyVNXIIznvyB46zsrve2MkgEIMAOGwGkX8OSxzT91b-MMVSrtMRuaxq8U=",
    "TrackID": "1iYaKPGLEi_9pp2ApKCSCzEuuRkcGqN_zGA6PeUlr3SoOihv5CZAemX21AM8Z0mJ9AzmLF4sdK6DvErUY7nQHJR07HUQ4oA5zT9FSBS2ZTZM",
    "thor": "251ECB82F51D8C8D4E3D1428DB84C3209944C3190610545ADFD85FB4E0138CA71473943BD4BE9A96CC5C68B0D98732983CA71BD4F0DC6096D87F08DD4656F3AFAE6CE41DD06A5871F514F2AE3F8CC60042DB3A736E1BD8E1C5B46F21AC85163DB8537968DEAF72E78AAF5A7A2289BDA15F0EA2D7F33BBCC6CBDBCAA0FD8030163500518C810263075E9D5E46E4CF6D0CD4FE72F7406C52423BDCE5AD84C61F32",
    "light_key": "AASBKE7rOxgWQziEhC_QY6yaCKdoACgYkVMbUqldCY8H96hqBfpIjH_-6ybI-lgCWPw26Bdu",
    "pinId": "Z_RulOG-J27d71tPa3l1iw",
    "pin": "jd_DpKnwcKTUZZG",
    "unick": "t0wd2u0z6pw1vh",
    "ceshi3.com": "000",
    "_tp": "GSi0H9%2BqGDdfdwyFnYkXBw%3D%3D",
    "_pst": "jd_DpKnwcKTUZZG",
    "__jda": "143920055.1762437587129797165975.1762437587.1762612536.1762784948.8",
    "__jdc": "143920055",
    "flash": "3_CWsb21Ki-zezMSmzIIOmcSZ-x8qZoQP8YaUoIEjOlTLfATePZt_qaS10YzapuQqD82LBsp_2X2XNeyyvKJTyimtDnXUwLZL4K9pQCNwVezh2JRzFlBXIXtq4NWIqVs_QdM9SElq_1bCEV2f15Q04aOG1_46HT8aHTlbFiV6tqUK_ABj0OeMV",
    "shshshfpb": "BApXWldg1bf9AgPMD_dyr7y8kIlFTpbdqBiACcqtq9xJ1PdZfQqLGuRT8jwDOBrxJVASR2qjn-rL1Zg",
    "__jdb": "143920055.8.1762437587129797165975|8.1762784948",
    "cn": "0",
    "ipLoc-djd": "19-1601-50258-129167",
    "3AB9D23F7A4B3C9B": "L56UBSOLZOOA3MVSMDYCPHPWVNIZ5YMZ6Q335ZWGXT2BLQZHM2RMMRAMY7GO37XXZTQLJOXMMRGUSAAJRQ55M7YT6M",
    "sdtoken": "AAbEsBpEIOVjqTAKCQtvQu17S8Ur8ymdSWnbVGc4hPDnYfO2Pulm1ivYyq0wUVBAg6LRAv6-lyCYQUTguNz7TfMuxr8YlCJswURNsqoMseaLSvZY5-c6ZdhLBApL7TCUW7COedChoPuM_rvdRCCyKyiE7QAnmJJ19yr4-SNn"
}
url = "https://api.m.jd.com/api"

with open("h5st.js", "r", encoding="utf-8") as f:
    js = f.read()

time_stamp = int(time.time() * 1000)
for page in range(1, 2):
    body = {
        "enc": "utf-8",
        "pvid": "c8ee6f8f98ba4aeabf534a34348c0d87",
        "area": "19_1601_50258_129167",
        "page": page,
        "new_interval": True,
        "s": 26
    }

    h5st = execjs.compile(js).call("get_h5st", body, str(time_stamp))

    # print('h5st的值为=======>', h5st)
    params = {
        "appid": "search-pc-java",
        "t": [
            str(time_stamp),
            str(time_stamp + random.randint(10, 20))
        ],
        "client": "pc",
        "clientVersion": "1.0.0",
        "cthr": "1",
        "uuid": "1762437587129797165975",
        "loginType": "3",
        "keyword": "美妆",
        "functionId": "pc_search_searchWare",
        "body": json.dumps(body, separators=(',', ':')),
        "x-api-eid-token": "jdd03L56UBSOLZOOA3MVSMDYCPHPWVNIZ5YMZ6Q335ZWGXT2BLQZHM2RMMRAMY7GO37XXZTQLJOXMMRGUSAAJRQ55M7YT6MAAAAM2NY6ICIQAAAAACADDIHLUUW7FG4X",
        "h5st": h5st
    }
    response = requests.get(url, headers=headers, cookies=cookies, params=params)
    data_list = response.json()
    wareName = data_list.get("data", {}).get("wareList")
    for ware in wareName:
        print(ware.get("wareName"))
