require('./env')
window.PSign = new ParamsSign({
    //融合接口加签
    appId: "b5216",
    //online
    debug: false,
    preRequest: false,
    onSign: function(res) {},
    // 算法请求监控回调事件 code: 200 - 请求成功，表示动态算法接口请求成功，获取到动态token 。 其他为失败
    onRequestTokenRemotely: function(res) {},
    onRequestToken: function(code, message) {}
});
// console.log('======>', window.yongsheng.prototype)
const ys_encrypt = new window.yongsheng()
// 1761661726153
aaa = {
    "appid": "www-jd-com",
    "body": "c3b8546034b6b2d3be7b58ad10858c9480423bb23dd83d2f75479c4ac471c003",
    "clientVersion": "1.0.0",
    "client": "pc",
    "functionId": "pc_home_feed",
    "t": 1761661607462
}
bbb = {
    "_token": "tk03wb8b81cf318nYqMUSSbN53lE3wb7CzFQiTEm5pm7xt1_ZyO-Sod-_hbckghacgwlYOcmJKRkbgx1hd8mpLNRj80k",
    "_defaultToken": "",
    "_isNormal": true,
    "_appId": "b5216",
    "_defaultAlgorithm": {},
    "_algos": {},
    "_version": "5.2",
    "_fingerprint": "m96gwtagi0jj36w6",
    "_debug": false
}
console.log(ys_encrypt._$cps(aaa));
// [
//   { key: 'appid', value: 'www-jd-com' },
//   {
//     key: 'body',
//     value: 'c3b8546034b6b2d3be7b58ad10858c9480423bb23dd83d2f75479c4ac471c003'
//   },
//   { key: 'client', value: 'pc' },
//   { key: 'clientVersion', value: '1.0.0' },
//   { key: 'functionId', value: 'pc_home_feed' },
//   { key: 't', value: 1761661607462 }
// ]

// "2|0|4|3|1"
obj1 = "2|0|4|3|1".split("|")  //[ '2', '0', '4', '3', '1' ]
console.log(obj1);
env1 = '{\n  "sua": "Windows NT 10.0; Win64; x64",\n  "pp": {},\n  "extend": {\n    "wd": 0,\n    "l": 0,\n    "ls": 5,\n    "wk": 0,\n    "bu1": "0.1.4",\n    "bu3": 45,\n    "bu4": 0,\n    "bu5": 0,\n    "bu6": 28,\n    "bu7": 0,\n    "bu8": 0,\n    "random": "912m3m_qjeaA",\n    "bu12": -8,\n    "bu10": 14,\n    "bu11": 2,\n    "bu13": "Fg"\n  },\n  "pf": "Win32",\n  "random": "bR21nav_7G9AT",\n  "v": "h5_file_v5.2.2",\n  "bu4": "0",\n  "canvas": "34310898711cbc67e174afd9403101a4",\n  "webglFp": "4a3d5a4e1ed70f80da6f60583689d1fa",\n  "ccn": 16,\n  "fp": "m96gwtagi0jj36w6"\n}'
console.log("__collect envCollect=".concat(env1));
// __collect envCollect={"sua":"Windows NT 10.0; Win64; x64","pp":{},"extend":{"wd":0,"l":0,"ls":5,"wk":0,"bu1":"0.1.4","bu3":45,"bu4":0,"bu5":0,"bu6":28,"bu7":0,"bu8":0,"random":"912m3m_qjeaA","bu12":-8,"bu10":14,"bu11":2,"bu13":"Fg"},"pf":"Win32","random":"bR21nav_7G9AT","v":"h5_file_v5.2.2","bu4":"0","canvas":"34310898711cbc67e174afd9403101a4","webglFp":"4a3d5a4e1ed70f80da6f60583689d1fa","ccn":16,"fp":"m96gwtagi0jj36w6"}
// console.log(ys_encrypt._$clt());
// obj2 = {
//     "words": [
//         2064261152,
//         577992033,
//         574234658,
//         1466527332,
//         1870099232,
//         1314136113,
//         808333371,
//         542599534,
//         909392672,
//         2016818210,
//         738861088,
//         577794082,
//         975207293,
//         738861088,
//         577075316,
//         1701733410,
//         975207178,
//         538976288,
//         578249762,
//         975188012,
//         169877536,
//         539126818,
//         975188012,
//         169877536,
//         539126899,
//         574234677,
//         738861088,
//         538976887,
//         1797405216,
//         808192544,
//         538976290,
//         1651847458,
//         975184432,
//         774975028,
//         573311520,
//         538976290,
//         1651847970,
//         975189045,
//         738861088,
//         538976866,
//         1966350906,
//         540027914,
//         538976288,
//         576877877,
//         574234672,
//         738861088,
//         538976866,
//         1966481978,
//         540162092,
//         169877536,
//         539124341,
//         924989984,
//         808192544,
//         538976290,
//         1651849250,
//         975188012,
//         169877536,
//         539128417,
//         1852075885,
//         574234658,
//         959525485,
//         862805873,
//         1785028929,
//         573311520,
//         538976290,
//         1651847474,
//         574234669,
//         942410272,
//         538976290,
//         1651847472,
//         574234673,
//         875301408,
//         538976290,
//         1651847473,
//         574234674,
//         738861088,
//         538976866,
//         1966158626,
//         975184454,
//         1730284064,
//         545074186,
//         538976880,
//         1713519136,
//         576153966,
//         858923564,
//         169877538,
//         1918987876,
//         1869423162,
//         539124306,
//         842100321,
//         1985951559,
//         960582690,
//         738861088,
//         578167354,
//         539125813,
//         1600547180,
//         1700754997,
//         775040562,
//         573311520,
//         539124341,
//         874658336,
//         573579820,
//         169877538,
//         1667329654,
//         1634935354,
//         539112244,
//         858861624,
//         959985457,
//         828596835,
//         909600049,
//         926179686,
//         1681470512,
//         858861617,
//         1630806572,
//         169877538,
//         2003133031,
//         1816555554,
//         975184436,
//         1630757941,
//         1630823729,
//         1701066544,
//         1714958436,
//         1630955062,
//         808794163,
//         909654372,
//         828793122,
//         738861088,
//         576938862,
//         574234673,
//         908855840,
//         539125360,
//         574234658,
//         1832466023,
//         2004115815,
//         1764780650,
//         859207478,
//         571112704
//     ],
//     "sigBytes": 547
// }
console.log('window._$uA=======>', window._$uA.Utf8.parse(env1))
// fZRCXZ-UqIuV34bV4ELJtEqIr9OG-h-T-h6I-hfZXx-Uwh-T-prJ_YfZB5hW-d7IwRLTpJuVpNeVrJ7UAQbVpJbVqRLIwNbUAMeIudbU-h-T-h6Q1E7J8E6ZBh-f1ZfUAceVwVeVt9eI7cbUqdOIqJuJ-ULVwFeToBeVwVeUuZfZnZvFAI6GAU7ZB
// h-f1ZfV-h-T-ROE-YfZB5hW-Z_WvpPUrkMI187ICMeH-h-T-J6ZBh-f1ZfMg8uQql8EAoLVvZ8J-h-T-trG9oLJvYfZB5hW-ZuVz8rM-h-T-JbF-hfZXxPCBh-f-F7Q-h-T-VOVsY7ZBhfZB5hWvh-T-dOVsY7ZBhfZB5hWtdeZnZfVwN6J-hfZBh-f1BOWB5_ZvdOE-YfZBh
// fZXx-ZgcLI3cqK0UOGvdOT-h-T-trG9oLJvYfZBhfZXxfVB5_ZpN6J-hfZBh-f1heZnZvUsY7ZBhfZB5hWpZeZnZ-UsY7ZBhfZB5hWxh-T-NOE-YfZBhfZXxfVB5_ZtN6J-hfZBh-f1NeUB5_ZuN6J-hfZBh-f1ZfUzd_WxZfZnZPVsY7ZBhfZB5hWxh-T-1rE-hfZBh-f1NeZnZvF1YfZBhfZXxfVB5_Z1YfZBhfZXxfVB5_Z9E6ZBhfZB5xDB5_Z9oLItAKI-hfZXxPCmg-T-haF-hfZXx-ZtJeDB1eUrpLHKgvTxpfVwhfMTgvFqkbIz8rM-h-T-dLEuYfZB5xD
console.log('window._$uA.Base64.encode=======>', window._$uA.Base64.encode(window._$uA.Utf8.parse(env1)))
console.log(ys_encrypt._$ms(ys_encrypt._$cps(aaa), window._$uA.Base64.encode(window._$uA.Utf8.parse(env1))).h5st.split(';'));
console.log(ys_encrypt._$ms(ys_encrypt._$cps(aaa), window._$uA.Base64.encode(window._$uA.Utf8.parse(env1))).h5st.length);
process.exit()